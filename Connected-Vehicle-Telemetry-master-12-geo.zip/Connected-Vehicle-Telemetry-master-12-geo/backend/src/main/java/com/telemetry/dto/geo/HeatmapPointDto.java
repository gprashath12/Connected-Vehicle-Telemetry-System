package com.telemetry.dto.geo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HeatmapPointDto {

    /** kind: speeding | idle | harsh-brake | any */
    private String kind;
    private List<Cell> cells;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Cell {
        private double lat;
        private double lon;
        /** Number of readings that fell into this grid cell. */
        private int weight;
    }
}
