package com.telemetry.service;

import com.telemetry.dto.geo.HeatmapPointDto;
import com.telemetry.entity.Role;
import com.telemetry.entity.User;
import com.telemetry.entity.Vehicle;
import com.telemetry.entity.VehicleReading;
import com.telemetry.repository.VehicleReadingRepository;
import com.telemetry.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Lightweight aggregation for heatmap rendering. Buckets points into a coarse
 * lat/lon grid so the payload stays small even over long windows.
 */
@Service
@RequiredArgsConstructor
public class GeoAnalyticsService {

    private final VehicleRepository vehicleRepo;
    private final VehicleReadingRepository readingRepo;

    /**
     * @param kind speeding | idle | any
     * @param speedThreshold for "speeding", readings with speed >= this are counted (default 90 km/h)
     * @param gridPrecision decimal digits of lat/lon to round to (3 → ~110m, 4 → ~11m)
     */
    public HeatmapPointDto heatmap(String kind, long fromMs, long toMs,
                                   double speedThreshold, int gridPrecision,
                                   User current) {

        List<Vehicle> visible = (current.getRole() == Role.ADMIN)
                ? vehicleRepo.findAll()
                : vehicleRepo.findByOwnerOrdered(current.getUserId());

        Instant from = Instant.ofEpochMilli(fromMs);
        Instant to = Instant.ofEpochMilli(toMs);
        Map<String, int[]> cells = new HashMap<>();   // key -> {count}
        Map<String, double[]> centroids = new HashMap<>(); // key -> {lat, lon}

        double mult = Math.pow(10, Math.max(1, Math.min(gridPrecision, 5)));
        String k = kind == null ? "any" : kind.toLowerCase();

        for (Vehicle v : visible) {
            List<VehicleReading> readings = readingRepo
                    .findByVehicleidAndTsBetweenOrderByTsAsc(v.getVehicleid(), from, to);
            for (VehicleReading r : readings) {
                if (r.getLat() == null || r.getLon() == null) continue;
                double s = r.getSpeed() == null ? 0 : r.getSpeed();
                boolean keep = switch (k) {
                    case "speeding" -> s >= speedThreshold;
                    case "idle" -> s < 1.0;
                    default -> true;
                };
                if (!keep) continue;
                double cellLat = Math.round(r.getLat() * mult) / mult;
                double cellLon = Math.round(r.getLon() * mult) / mult;
                String key = cellLat + "," + cellLon;
                cells.computeIfAbsent(key, x -> new int[]{0})[0]++;
                centroids.computeIfAbsent(key, x -> new double[]{ cellLat, cellLon });
            }
        }

        List<HeatmapPointDto.Cell> out = new ArrayList<>(cells.size());
        for (Map.Entry<String, int[]> e : cells.entrySet()) {
            double[] ll = centroids.get(e.getKey());
            out.add(new HeatmapPointDto.Cell(ll[0], ll[1], e.getValue()[0]));
        }
        return new HeatmapPointDto(k, out);
    }
}
