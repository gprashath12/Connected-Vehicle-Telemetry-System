# Geo & mapping upgrades

This document covers the geo/mapping feature pack added on top of the original
Connected Vehicle Telemetry project. None of the existing endpoints or pages were
changed — everything below is additive.

## Feature list

| Feature | Status |
|---|---|
| Geofencing (polygon CRUD, entry/exit events, ack workflow) | ✅ Full |
| Trip detection (gap-based segmentation of readings) | ✅ Full |
| Trip playback (map replay with timeline scrubber) | ✅ Full |
| Live heatmap (speeding, idle, all-activity) | ✅ Full |
| Snap-to-road via OSRM `/match` | ✅ Optional, disabled by default |
| 3D fleet view with deck.gl / CesiumJS | 📝 Not built — see notes below |
| ETA & multi-stop route optimization | 📝 Not built — see notes below |
| Offline tiles with PMTiles | 📝 Not built — see notes below |

---

## What you can do now

### As any logged-in user

- **Draw geofences** at `/geofences`. Click on the map to add vertices (≥ 3),
  pick a name, category, color, and entry/exit alert toggles, then save.
- **Get notified** when one of your vehicles enters or leaves a fence. The bell
  icon in the topbar shows the unacknowledged count; clicking it jumps to the
  events table where you can acknowledge them.
- **Replay trips** at `/trips`. Pick a vehicle, pick a trip from the history,
  hit play. Scrub with the timeline, adjust playback speed (1× → 32×).
- **See heatmaps** at `/heatmap`. Three modes:
  - *Speeding hotspots* — adjust the threshold from 40 to 140 km/h
  - *Idle zones* — where vehicles sit with the engine running but not moving
  - *All activity* — every reading

### As an admin

Admins see every owner's geofences, trips, and events. The same pages work,
just with a wider data scope.

---

## Backend additions

### New entities

```
geofence (geofence_id, name, description, category, color, polygon_json,
          min_lat/max_lat/min_lon/max_lon bbox cache, enabled,
          alert_on_entry, alert_on_exit, owner_id, created_at)

geofence_event (event_id, vehicleid, geofence_id, event_type ENTRY|EXIT,
                lat, lon, speed, ts, acknowledged)

trip (trip_id, vehicleid, start_ts, end_ts, start_lat/lon, end_lat/lon,
      distance_km, max_speed, avg_speed, idle_minutes, point_count,
      snapped_geometry)
```

Hibernate's `ddl-auto=update` will create them on first run.

### New REST endpoints

All under `/api/`, all gated by the existing JWT auth + ownership checks.

| Method | Path | Purpose |
|---|---|---|
| GET | `/geofences` | List geofences you own (admin: all) |
| GET | `/geofences/{id}` | Fetch one |
| POST | `/geofences` | Create — body is `CreateGeofenceRequest` |
| PUT | `/geofences/{id}` | Update |
| DELETE | `/geofences/{id}` | Delete (cascades to its events) |
| GET | `/geofences/events` | Recent events across your vehicles |
| GET | `/geofences/events/unacknowledged-count` | `{count: N}` for the bell badge |
| POST | `/geofences/events/{id}/ack` | Mark an event acknowledged |
| GET | `/trips/vehicle/{id}` | List trips, optional `from`/`to` (epoch ms) |
| GET | `/trips/{id}` | Full trip with point sequence and snapped geometry |
| POST | `/trips/{id}/snap` | Re-run OSRM snap-to-road |
| POST | `/trips/vehicle/{id}/rebuild` | Re-segment from raw readings |
| GET | `/geo-analytics/heatmap` | Grid-bucketed aggregation. Query: `kind`, `from`, `to`, `threshold`, `precision` |

### How geofence evaluation works

`VehicleSimulator.tick()` now calls `GeofenceService.evaluate(vehicle, lat, lon, speed, ts)`
right before persisting the new reading. The service:

1. Loads all enabled geofences belonging to the vehicle's owner.
2. For each, does a fast bbox-reject test, then full ray-casting point-in-polygon.
3. Compares the resulting "currently inside" set to the cached "previously inside"
   set (held in memory in a `ConcurrentHashMap`, keyed by vehicle id).
4. Persists ENTRY/EXIT events for any transitions, respecting each fence's
   `alertOnEntry` / `alertOnExit` toggles.

The membership cache means we never need to query historical readings to detect
transitions — only the per-vehicle delta of the current tick matters.

### How trips are detected

`TripService.rebuildAll()` runs every 5 minutes (`telemetry.trips.rebuild-rate-ms`).
For each vehicle it:

1. Looks up the latest `end_ts` already on file.
2. Pulls readings newer than `last_end_ts − gap_minutes` so an in-progress trip
   ending in the gap window can still be finalized.
3. Walks them, splitting whenever the inter-reading delta exceeds `gap_minutes`
   (default 10 min). The simulator deliberately writes no row during OFF
   periods, so OFF naturally appears as a gap.
4. Discards micro-trips below `min_distance_km` (drifting GPS while parked).
5. Saves any segment whose `start_ts` is newer than the last known `end_ts`.

The most recent segment is left alone unless it's old enough to be considered
"complete" (`now − gap_minutes`). This way a long ongoing drive doesn't get
prematurely cut in half.

After seeding, `DataSeeder` calls `tripService.seedRebuild()` to one-shot build
trip history from the 30 days of seeded readings.

### Snap-to-road (OSRM)

Disabled by default. To enable:

```properties
telemetry.osrm.enabled=true
telemetry.osrm.base-url=https://router.project-osrm.org    # or your self-hosted URL
telemetry.osrm.profile=driving
```

The public demo server (`router.project-osrm.org`) works for tiny demos but is
rate-limited and you'll get failures under any real load. For production, run
your own OSRM container:

```bash
docker run -t -i -p 5000:5000 -v "$(pwd):/data" \
  ghcr.io/project-osrm/osrm-backend osrm-routed --algorithm mld /data/region.osrm
```

then point `telemetry.osrm.base-url=http://localhost:5000`.

Snap happens lazily — call `POST /api/trips/{id}/snap` (the "Snap to road"
button in the UI), or set `telemetry.trips.snap-on-rebuild=true` to snap every
new trip automatically during the scheduled rebuild.

> ⚠️ **Anti-pattern note**: `snapTrip()` is `@Transactional` and makes an
> external HTTP call. For a demo that's fine; for production move the HTTP call
> outside the transaction (or use a non-tx wrapper) so you don't tie up DB
> connections while waiting on OSRM.

---

## Frontend additions

### New pages

| Path | File |
|---|---|
| `/geofences` | `pages/GeofencesPage.jsx` |
| `/trips`     | `pages/TripsPage.jsx` |
| `/heatmap`   | `pages/HeatmapPage.jsx` |

### New components

```
components/geo/
├── PolygonDrawer.jsx        — click-on-map polygon creation, no extra plugins
├── GeofenceMap.jsx          — read-only multi-polygon viewer
├── GeofenceEventsTable.jsx  — recent entry/exit log with ack buttons
├── GeofenceAlertBell.jsx    — topbar badge for unacknowledged events
├── TripPlayer.jsx           — map + timeline scrubber + transport controls
└── HeatmapLayer.jsx         — weighted circle markers, no leaflet.heat needed
```

### New API clients

```
src/api/geofences.js     — geofence CRUD + events
src/api/trips.js         — trip list/detail/snap/rebuild
src/api/geoAnalytics.js  — heatmap aggregation
```

### Dependencies

Nothing new — everything is built on the existing React Leaflet + React Query
stack. No `leaflet-draw`, no `leaflet.heat`. Polygon drawing uses raw click
handlers, and the heatmap is a `CircleMarker` overlay sized and colored by cell
weight.

---

## Features intentionally NOT built

### 3D fleet view (deck.gl / CesiumJS)

Both libraries are heavy (deck.gl ≈ 600 KB, Cesium ≈ 4 MB) and don't integrate
cleanly into the existing Leaflet stack — they want their own canvas/WebGL
context. The cleanest way to add this is a dedicated `/fleet-3d` page that
renders a deck.gl `ScatterplotLayer` over a `MapboxOverlay` base map. If you go
this route you'll need a Mapbox token (or use MapLibre with a vector tile
source).

### Multi-stop route optimization (TSP/VRP)

OSRM also exposes a `/trip` endpoint that solves a basic TSP. The
`OsrmClient` could be extended with a `routeWithWaypoints(List<LatLon>)` method
that calls `GET /trip/v1/driving/{coords}?source=first&destination=last&roundtrip=false`.
The result has the same GeoJSON LineString shape so it slots into the same
`snappedGeometry` field.

For real multi-vehicle VRP you'd want OR-Tools (Java port) or VROOM.

### Offline tiles with PMTiles

PMTiles is a single-file pyramid you can serve straight from S3 or any static
host. To integrate:

1. Generate a PMTiles archive of your region with `tippecanoe` + `pmtiles`.
2. Drop the [pmtiles-protocol](https://github.com/protomaps/PMTiles) JS into
   the frontend.
3. Replace `<TileLayer url=".../{z}/{x}/{y}.png" />` with a Protomaps tile
   layer that resolves to the PMTiles file.

This is mostly a frontend swap — the backend doesn't change.

---

## Quick test plan after first boot

1. Start backend (`mvn spring-boot:run`) — seeding will run and trip history
   will be built once.
2. Start frontend (`npm run dev`).
3. Log in as `admin@gmail.com / Admin@123`.
4. Go to **/trips**, pick any vehicle — you should see ~30 days of trips.
   Click one and hit play.
5. Go to **/geofences**, click "New geofence", click 4 points on the map
   around Bangalore (the seeded location), save.
6. Wait one simulator tick (≤ 60 s). When a vehicle's drift puts it inside or
   outside your polygon, an event appears on the same page and the bell icon
   in the topbar lights up.
7. Go to **/heatmap**, switch between speeding / idle / all — change the
   threshold and the range to see the picture shift.
