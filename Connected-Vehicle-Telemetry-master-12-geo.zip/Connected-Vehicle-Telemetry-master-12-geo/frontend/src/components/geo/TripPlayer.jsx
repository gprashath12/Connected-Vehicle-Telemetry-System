import { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Popup, CircleMarker, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Play, Pause, SkipBack, SkipForward, Gauge, Thermometer, MapPin, Activity } from 'lucide-react';
import { formatClockTime, formatDuration } from '../../lib/timeAgo';

const PLAYBACK_RATES = [1, 2, 4, 8, 16, 32];

/**
 * Trip playback: shows the full route as a polyline (raw GPS) and optionally a
 * snapped route as a dashed overlay, with a marker that moves along the path
 * driven by a timeline scrubber.
 */
export default function TripPlayer({ detail, height = 480 }) {
  const points = detail?.points ?? [];
  const snapped = detail?.snappedRoute; // [[lon, lat], ...]

  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [rate, setRate] = useState(8);
  const tickRef = useRef(null);

  // Auto-advance when playing
  useEffect(() => {
    if (!playing || points.length < 2) return undefined;
    tickRef.current = setInterval(() => {
      setIndex((i) => {
        const next = i + 1;
        if (next >= points.length) {
          setPlaying(false);
          return i;
        }
        return next;
      });
    }, Math.max(50, 1000 / rate));
    return () => clearInterval(tickRef.current);
  }, [playing, rate, points.length]);

  // Reset to start when a new trip is loaded
  useEffect(() => {
    setIndex(0);
    setPlaying(false);
  }, [detail?.trip?.tripId]);

  const polyline = useMemo(() => points.map((p) => [p.lat, p.lon]), [points]);
  const snappedLine = useMemo(
    () => (snapped ? snapped.map(([lon, lat]) => [lat, lon]) : null),
    [snapped],
  );

  const current = points[index];
  const startTs = points[0]?.ts;
  const elapsedMin = current && startTs ? (current.ts - startTs) / 60_000 : 0;

  const center = useMemo(() => {
    if (current) return [current.lat, current.lon];
    if (points.length) {
      const lat = points.reduce((s, p) => s + p.lat, 0) / points.length;
      const lon = points.reduce((s, p) => s + p.lon, 0) / points.length;
      return [lat, lon];
    }
    return [12.97, 77.59];
  }, [current, points]);

  if (!points.length) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-10 text-center text-sm text-slate-500 dark:text-slate-400">
        No points available for this trip.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden relative">
        <MapContainer
          center={center}
          zoom={13}
          style={{ height: `${height}px`, width: '100%' }}
          scrollWheelZoom
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {/* Raw GPS trail */}
          <Polyline positions={polyline} pathOptions={{ color: '#94a3b8', weight: 3, opacity: 0.7 }} />

          {/* Snapped road geometry, if available */}
          {snappedLine && (
            <Polyline
              positions={snappedLine}
              pathOptions={{ color: '#2563eb', weight: 4, opacity: 0.9, dashArray: null }}
            />
          )}

          {/* Start and end markers */}
          <CircleMarker
            center={[points[0].lat, points[0].lon]}
            radius={7}
            pathOptions={{ color: '#10b981', fillColor: '#10b981', fillOpacity: 1, weight: 2 }}
          >
            <Popup>Start — {formatClockTime(new Date(points[0].ts))}</Popup>
          </CircleMarker>
          <CircleMarker
            center={[points[points.length - 1].lat, points[points.length - 1].lon]}
            radius={7}
            pathOptions={{ color: '#ef4444', fillColor: '#ef4444', fillOpacity: 1, weight: 2 }}
          >
            <Popup>End — {formatClockTime(new Date(points[points.length - 1].ts))}</Popup>
          </CircleMarker>

          {/* The moving "vehicle" marker */}
          {current && (
            <Marker position={[current.lat, current.lon]} icon={vehicleIcon(current.speed)}>
              <Popup>
                <div className="text-xs leading-relaxed">
                  <div>{formatClockTime(new Date(current.ts))}</div>
                  <div>Speed: <strong>{current.speed.toFixed(0)} km/h</strong></div>
                  <div>Engine: <strong>{current.engineTemp.toFixed(0)} °C</strong></div>
                </div>
              </Popup>
            </Marker>
          )}

          {current && <RecenterOnIndex position={[current.lat, current.lon]} />}
        </MapContainer>

        {/* Overlay HUD */}
        {current && (
          <div className="absolute top-3 left-3 z-[1000] bg-white/95 dark:bg-slate-800/95 backdrop-blur border border-slate-200 dark:border-slate-700 rounded-lg shadow px-3 py-2 text-xs text-slate-700 dark:text-slate-200 space-y-1">
            <div className="flex items-center gap-2">
              <Gauge className="h-3.5 w-3.5 text-slate-400" />
              <span className="tabular-nums">{current.speed.toFixed(0)} km/h</span>
            </div>
            <div className="flex items-center gap-2">
              <Thermometer className="h-3.5 w-3.5 text-slate-400" />
              <span className="tabular-nums">{current.engineTemp.toFixed(0)} °C</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="h-3.5 w-3.5 text-slate-400" />
              <span>{formatDuration(elapsedMin)} elapsed</span>
            </div>
          </div>
        )}
      </div>

      {/* Transport controls */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 space-y-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIndex(0)}
            className="p-1.5 rounded text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Jump to start"
          >
            <SkipBack className="h-4 w-4" />
          </button>
          <button
            onClick={() => setPlaying((p) => !p)}
            className="p-2 rounded-md bg-brand-600 text-white hover:bg-brand-700 transition"
            aria-label={playing ? 'Pause' : 'Play'}
          >
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </button>
          <button
            onClick={() => setIndex(points.length - 1)}
            className="p-1.5 rounded text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Jump to end"
          >
            <SkipForward className="h-4 w-4" />
          </button>

          <div className="ml-2 flex items-center gap-1">
            {PLAYBACK_RATES.map((r) => (
              <button
                key={r}
                onClick={() => setRate(r)}
                className={`px-2 py-0.5 rounded text-xs font-medium transition ${
                  rate === r
                    ? 'bg-brand-100 text-brand-700 dark:bg-brand-500/20 dark:text-brand-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {r}×
              </button>
            ))}
          </div>

          <div className="ml-auto text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {current && formatClockTime(new Date(current.ts))} • Point {index + 1}/{points.length}
          </div>
        </div>

        <input
          type="range"
          min={0}
          max={Math.max(0, points.length - 1)}
          step={1}
          value={index}
          onChange={(e) => {
            setIndex(Number(e.target.value));
            setPlaying(false);
          }}
          className="w-full accent-brand-600"
        />

        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span className="flex items-center gap-1">
            <MapPin className="h-3 w-3" /> Start {formatClockTime(new Date(points[0].ts))}
          </span>
          <span>End {formatClockTime(new Date(points[points.length - 1].ts))}</span>
        </div>
      </div>
    </div>
  );
}

/** Smoothly recenter the map as the marker moves. */
function RecenterOnIndex({ position }) {
  const map = useMap();
  useEffect(() => {
    if (!position) return;
    map.panTo(position, { animate: true, duration: 0.25 });
  }, [position, map]);
  return null;
}

function vehicleIcon(speed) {
  const color = speed > 80 ? '#ef4444' : speed > 1 ? '#2563eb' : '#94a3b8';
  return L.divIcon({
    className: 'trip-player-marker',
    iconSize: [22, 22],
    iconAnchor: [11, 11],
    html: `
      <div style="position:relative;width:22px;height:22px;">
        <span style="position:absolute;inset:-4px;border-radius:9999px;background:${color}40;animation:trip-pulse 1.4s ease-out infinite;"></span>
        <span style="position:absolute;inset:0;border-radius:9999px;background:${color};border:2.5px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,0.3);"></span>
      </div>
      <style>@keyframes trip-pulse{0%{transform:scale(0.6);opacity:0.9}100%{transform:scale(1.8);opacity:0}}</style>
    `,
  });
}
