import { useEffect, useRef, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Truck,
  LayoutGrid,
  BarChart2,
  Gauge,
  LayoutDashboard,
  Users,
  MapPin,
  Route,
  Flame,
  Menu,
  X,
  CircleUser,
  LogOut,
  ShieldCheck,
  ChevronDown,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import ThemeToggle from '../common/ThemeToggle';
import GeofenceAlertBell from '../geo/GeofenceAlertBell';

export default function Navbar() {
  const { user, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const homeRoute = isAdmin ? '/admin/dashboard' : '/';

  const [mobileOpen, setMobileOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const userRef = useRef(null);

  useEffect(() => {
    function handler(e) {
      if (userRef.current && !userRef.current.contains(e.target)) {
        setUserOpen(false);
      }
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const navItems = isAdmin
    ? [
        { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { to: '/analytics', label: 'Analytics', icon: BarChart2 },
        { to: '/engine-health', label: 'Engine Health', icon: Gauge },
        { to: '/trips', label: 'Trips', icon: Route },
        { to: '/geofences', label: 'Geofences', icon: MapPin },
        { to: '/heatmap', label: 'Heatmap', icon: Flame },
        { to: '/admin/clients', label: 'Clients', icon: Users },
      ]
    : [
        { to: '/', label: 'Vehicles', icon: LayoutGrid, end: true },
        { to: '/analytics', label: 'Analytics', icon: BarChart2 },
        { to: '/engine-health', label: 'Engine Health', icon: Gauge },
        { to: '/trips', label: 'Trips', icon: Route },
        { to: '/geofences', label: 'Geofences', icon: MapPin },
        { to: '/heatmap', label: 'Heatmap', icon: Flame },
      ];

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="px-4 h-[60px] flex items-center gap-2">
        {/* Logo */}
        <button
          onClick={() => navigate(homeRoute)}
          className="flex items-center gap-2 shrink-0 mr-2 hover:opacity-90 transition-opacity"
        >
          <div className="h-8 w-8 rounded-lg bg-brand-600 flex items-center justify-center">
            <Truck className="h-4 w-4 text-white" />
          </div>
          <div className="leading-tight text-left hidden sm:block">
            <div className="font-bold text-slate-900 dark:text-slate-100 text-[15px]">
              Telemetry
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400 -mt-0.5">
              Vehicle Console
            </div>
          </div>
        </button>

        <div className="h-5 w-px bg-slate-200 dark:bg-slate-700 mx-1 hidden md:block" />

        {/* Desktop nav links */}
        <nav className="hidden md:flex items-stretch flex-1 gap-0.5 self-stretch">
          {navItems.map(({ to, label, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                [
                  'relative flex items-center px-3 text-sm font-medium transition-colors',
                  'border-b-[3px] h-full',
                  isActive
                    ? 'text-brand-600 dark:text-brand-400 border-b-brand-600 dark:border-b-brand-400'
                    : 'text-slate-600 dark:text-slate-300 border-b-transparent hover:text-brand-600 dark:hover:text-brand-400 hover:border-b-brand-300 dark:hover:border-b-brand-700',
                ].join(' ')
              }
            >
              {label}
              {isAdmin && label === 'Dashboard' && (
                <span className="ml-1.5 inline-flex items-center gap-0.5 text-[9px] font-bold uppercase tracking-wide px-1 py-0.5 rounded bg-brand-600 text-white">
                  <ShieldCheck className="h-2.5 w-2.5" />
                  Admin
                </span>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2 ml-auto">
          <GeofenceAlertBell />
          <ThemeToggle />

          {/* User dropdown */}
          <div className="relative" ref={userRef}>
            <button
              onClick={() => setUserOpen((o) => !o)}
              className="flex items-center gap-1.5 pl-2 border-l border-slate-200 dark:border-slate-700 h-8"
            >
              <CircleUser className="h-7 w-7 text-slate-400" />
              <div className="hidden lg:block leading-tight text-left">
                <div className="text-sm font-medium text-slate-900 dark:text-slate-100 max-w-[120px] truncate">
                  {user?.fullName || user?.email}
                </div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400">
                  {user?.role}
                </div>
              </div>
              <ChevronDown className="h-3.5 w-3.5 text-slate-400 hidden lg:block" />
            </button>

            {userOpen && (
              <div className="absolute right-0 mt-2 w-52 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg z-50">
                <div className="px-3 py-2.5 border-b border-slate-100 dark:border-slate-800">
                  <div className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {user?.fullName}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {user?.email}
                  </div>
                  {isAdmin && (
                    <span className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded bg-brand-600 text-white">
                      <ShieldCheck className="h-2.5 w-2.5" />
                      Admin
                    </span>
                  )}
                </div>
                <button
                  onClick={() => {
                    setUserOpen(false);
                    logout();
                  }}
                  className="w-full text-left flex items-center gap-2 px-3 py-2.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-b-lg transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  Sign out
                </button>
              </div>
            )}
          </div>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileOpen((o) => !o)}
            className="md:hidden p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu dropdown */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2">
          {navItems.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                [
                  'flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100',
                ].join(' ')
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </div>
      )}
    </header>
  );
}
