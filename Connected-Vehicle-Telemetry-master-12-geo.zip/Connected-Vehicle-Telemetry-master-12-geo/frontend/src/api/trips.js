import { apiClient } from './client';

// GET /api/trips/vehicle/{vehicleId}?from=&to=
export async function fetchTripsForVehicle(vehicleId, from, to) {
  const params = {};
  if (from != null) params.from = from;
  if (to != null) params.to = to;
  const { data } = await apiClient.get(`/trips/vehicle/${vehicleId}`, { params });
  return data;
}

// GET /api/trips/{id}
export async function fetchTripDetail(id) {
  const { data } = await apiClient.get(`/trips/${id}`);
  return data;
}

// POST /api/trips/{id}/snap
export async function snapTrip(id) {
  const { data } = await apiClient.post(`/trips/${id}/snap`);
  return data;
}

// POST /api/trips/vehicle/{vehicleId}/rebuild
export async function rebuildTripsForVehicle(vehicleId) {
  const { data } = await apiClient.post(`/trips/vehicle/${vehicleId}/rebuild`);
  return data;
}
