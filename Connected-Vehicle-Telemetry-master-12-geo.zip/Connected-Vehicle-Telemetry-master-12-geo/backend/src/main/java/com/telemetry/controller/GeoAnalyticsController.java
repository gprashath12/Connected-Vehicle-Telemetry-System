package com.telemetry.controller;

import com.telemetry.dto.geo.HeatmapPointDto;
import com.telemetry.entity.User;
import com.telemetry.service.GeoAnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/geo-analytics")
@RequiredArgsConstructor
public class GeoAnalyticsController {

    private final GeoAnalyticsService service;

    /**
     * Heatmap data for the current user's visible vehicles.
     * Example: /api/geo-analytics/heatmap?kind=speeding&from=...&to=...&threshold=80&precision=3
     */
    @GetMapping("/heatmap")
    public HeatmapPointDto heatmap(
            @RequestParam(defaultValue = "any") String kind,
            @RequestParam long from,
            @RequestParam long to,
            @RequestParam(defaultValue = "80") double threshold,
            @RequestParam(defaultValue = "3") int precision,
            @AuthenticationPrincipal User current) {
        return service.heatmap(kind, from, to, threshold, precision, current);
    }
}
