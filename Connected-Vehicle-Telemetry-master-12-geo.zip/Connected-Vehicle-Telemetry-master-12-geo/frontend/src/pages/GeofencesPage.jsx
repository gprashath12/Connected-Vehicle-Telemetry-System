import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Pencil, Trash2, X, Save, AlertCircle, MapPin } from 'lucide-react';
import Topbar from '../components/layout/Topbar';
import { Card, CardHeader, CardBody } from '../components/common/Card';
import LoadingBlock from '../components/common/LoadingBlock';
import EmptyState from '../components/common/EmptyState';
import GeofenceMap from '../components/geo/GeofenceMap';
import PolygonDrawer from '../components/geo/PolygonDrawer';
import GeofenceEventsTable from '../components/geo/GeofenceEventsTable';
import {
  fetchGeofences,
  createGeofence,
  updateGeofence,
  deleteGeofence,
  fetchGeofenceEvents,
} from '../api/geofences';

const CATEGORIES = [
  { value: 'DEPOT', label: 'Depot', color: '#0ea5e9' },
  { value: 'CUSTOMER_SITE', label: 'Customer site', color: '#10b981' },
  { value: 'RESTRICTED', label: 'Restricted', color: '#ef4444' },
  { value: 'CUSTOM', label: 'Custom', color: '#2563eb' },
];

const POLL_MS = 30_000;

const EMPTY_DRAFT = {
  name: '',
  description: '',
  category: 'CUSTOM',
  color: '#2563eb',
  polygon: [],
  enabled: true,
  alertOnEntry: true,
  alertOnExit: true,
};

export default function GeofencesPage() {
  const queryClient = useQueryClient();
  const [selectedId, setSelectedId] = useState(null);
  const [editing, setEditing] = useState(null); // null | { id?: number, ...draft }

  const fencesQuery = useQuery({
    queryKey: ['geofences'],
    queryFn: fetchGeofences,
    refetchInterval: POLL_MS,
  });

  const eventsQuery = useQuery({
    queryKey: ['geofence-events'],
    queryFn: fetchGeofenceEvents,
    refetchInterval: POLL_MS,
  });

  const createMut = useMutation({
    mutationFn: createGeofence,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['geofences'] });
      setEditing(null);
    },
  });

  const updateMut = useMutation({
    mutationFn: ({ id, payload }) => updateGeofence(id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['geofences'] });
      setEditing(null);
    },
  });

  const deleteMut = useMutation({
    mutationFn: deleteGeofence,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['geofences'] });
      queryClient.invalidateQueries({ queryKey: ['geofence-events'] });
      setSelectedId(null);
    },
  });

  const fences = fencesQuery.data ?? [];
  const events = eventsQuery.data ?? [];

  const selected = useMemo(
    () => fences.find((f) => f.geofenceId === selectedId) ?? null,
    [fences, selectedId],
  );

  const handleSave = () => {
    if (!editing) return;
    if (!editing.name?.trim()) return alert('Name is required');
    if (!editing.polygon || editing.polygon.length < 3) return alert('Draw at least 3 polygon points');
    const payload = {
      name: editing.name.trim(),
      description: editing.description || '',
      category: editing.category,
      color: editing.color,
      polygon: editing.polygon,
      enabled: !!editing.enabled,
      alertOnEntry: !!editing.alertOnEntry,
      alertOnExit: !!editing.alertOnExit,
    };
    if (editing.id) {
      updateMut.mutate({ id: editing.id, payload });
    } else {
      createMut.mutate(payload);
    }
  };

  return (
    <>
      <Topbar
        title="Geofences"
        subtitle="Define polygonal regions and get notified when vehicles enter or leave them"
        right={
          <button
            onClick={() => setEditing({ ...EMPTY_DRAFT })}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium transition"
          >
            <Plus className="h-4 w-4" />
            New geofence
          </button>
        }
      />

      <div className="p-6 space-y-6">
        {editing ? (
          <Card>
            <CardHeader
              title={editing.id ? 'Edit geofence' : 'Create geofence'}
              subtitle="Click the map to add vertices, then fill in the details"
              action={
                <button
                  onClick={() => setEditing(null)}
                  className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              }
            />
            <CardBody className="space-y-5">
              <PolygonDrawer
                key={editing.id ?? 'new'}
                value={editing.polygon}
                onChange={(polygon) => setEditing((s) => ({ ...s, polygon }))}
                color={editing.color}
                existingFences={editing.id ? fences.filter((f) => f.geofenceId !== editing.id) : fences}
              />

              <div className="grid md:grid-cols-2 gap-4">
                <Field label="Name *">
                  <input
                    type="text"
                    value={editing.name}
                    onChange={(e) => setEditing((s) => ({ ...s, name: e.target.value }))}
                    placeholder="Bangalore depot"
                    className="input"
                  />
                </Field>
                <Field label="Category">
                  <select
                    value={editing.category}
                    onChange={(e) => {
                      const cat = e.target.value;
                      const def = CATEGORIES.find((c) => c.value === cat);
                      setEditing((s) => ({ ...s, category: cat, color: def?.color || s.color }));
                    }}
                    className="input"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </Field>
                <Field label="Description" className="md:col-span-2">
                  <input
                    type="text"
                    value={editing.description}
                    onChange={(e) => setEditing((s) => ({ ...s, description: e.target.value }))}
                    placeholder="Optional notes"
                    className="input"
                  />
                </Field>
                <Field label="Color">
                  <input
                    type="color"
                    value={editing.color}
                    onChange={(e) => setEditing((s) => ({ ...s, color: e.target.value }))}
                    className="h-9 w-16 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </Field>
                <Field label="Status">
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={editing.enabled}
                      onChange={(e) => setEditing((s) => ({ ...s, enabled: e.target.checked }))}
                    />
                    Enabled
                  </label>
                </Field>
                <Field label="Alerts">
                  <div className="flex gap-4 text-sm">
                    <label className="inline-flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editing.alertOnEntry}
                        onChange={(e) => setEditing((s) => ({ ...s, alertOnEntry: e.target.checked }))}
                      />
                      On entry
                    </label>
                    <label className="inline-flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editing.alertOnExit}
                        onChange={(e) => setEditing((s) => ({ ...s, alertOnExit: e.target.checked }))}
                      />
                      On exit
                    </label>
                  </div>
                </Field>
              </div>

              {(createMut.error || updateMut.error) && (
                <div className="flex items-center gap-2 text-sm text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-900/30 border border-rose-200 dark:border-rose-800 rounded-md px-3 py-2">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  {createMut.error?.message || updateMut.error?.message || 'Failed to save'}
                </div>
              )}

              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setEditing(null)}
                  className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={createMut.isPending || updateMut.isPending}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-brand-600 hover:bg-brand-700 disabled:opacity-50 text-white text-sm font-medium"
                >
                  <Save className="h-4 w-4" />
                  {editing.id ? 'Save changes' : 'Create geofence'}
                </button>
              </div>

              <FormStyles />
            </CardBody>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader
                title="Geofence map"
                subtitle={`${fences.length} polygon${fences.length === 1 ? '' : 's'} defined`}
              />
              <CardBody>
                {fencesQuery.isPending ? (
                  <LoadingBlock />
                ) : fences.length === 0 ? (
                  <EmptyState
                    icon={MapPin}
                    title="No geofences yet"
                    message='Click "New geofence" to draw your first polygon.'
                  />
                ) : (
                  <GeofenceMap
                    fences={fences}
                    selectedId={selectedId}
                    onSelect={setSelectedId}
                  />
                )}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Your geofences" />
              <CardBody className="p-0">
                {fences.length === 0 ? (
                  <p className="px-5 py-4 text-sm text-slate-500 dark:text-slate-400">Nothing here yet.</p>
                ) : (
                  <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                    {fences.map((g) => {
                      const isActive = selectedId === g.geofenceId;
                      return (
                        <li
                          key={g.geofenceId}
                          className={`px-5 py-3 flex items-start gap-3 cursor-pointer transition ${
                            isActive ? 'bg-brand-50 dark:bg-brand-500/10' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                          }`}
                          onClick={() => setSelectedId(g.geofenceId)}
                        >
                          <span
                            className="h-3 w-3 rounded mt-1 shrink-0"
                            style={{ backgroundColor: g.color || '#94a3b8' }}
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                                {g.name}
                              </span>
                              {!g.enabled && (
                                <span className="text-[10px] px-1 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                                  Disabled
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {g.category} • {g.polygon.length} pts
                            </div>
                          </div>
                          <div className="flex gap-1 opacity-70 group-hover:opacity-100">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditing({
                                  id: g.geofenceId,
                                  name: g.name,
                                  description: g.description || '',
                                  category: g.category,
                                  color: g.color || '#2563eb',
                                  polygon: g.polygon,
                                  enabled: g.enabled,
                                  alertOnEntry: g.alertOnEntry,
                                  alertOnExit: g.alertOnExit,
                                });
                              }}
                              className="p-1 rounded text-slate-500 hover:text-brand-600 hover:bg-slate-100 dark:hover:bg-slate-700"
                              aria-label="Edit"
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (confirm(`Delete geofence "${g.name}"?`)) {
                                  deleteMut.mutate(g.geofenceId);
                                }
                              }}
                              className="p-1 rounded text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-700"
                              aria-label="Delete"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardBody>
            </Card>
          </div>
        )}

        {!editing && (
          <Card>
            <CardHeader
              title="Recent activity"
              subtitle="Vehicle entries and exits across your geofences"
            />
            <CardBody>
              {eventsQuery.isPending ? (
                <LoadingBlock />
              ) : (
                <GeofenceEventsTable events={events} limit={50} />
              )}
            </CardBody>
          </Card>
        )}
      </div>
    </>
  );
}

function Field({ label, children, className = '' }) {
  return (
    <label className={`block text-sm ${className}`}>
      <span className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">{label}</span>
      {children}
    </label>
  );
}

function FormStyles() {
  return (
    <style>{`
      .input {
        width: 100%;
        background-color: #fff;
        border: 1px solid rgb(203 213 225);
        border-radius: 0.375rem;
        padding: 0.5rem 0.75rem;
        font-size: 0.875rem;
        color: rgb(15 23 42);
        outline: none;
        transition: border-color 150ms;
      }
      .input:focus { border-color: rgb(37 99 235); }
      html.dark .input {
        background-color: rgb(15 23 42);
        border-color: rgb(51 65 85);
        color: rgb(241 245 249);
      }
    `}</style>
  );
}
