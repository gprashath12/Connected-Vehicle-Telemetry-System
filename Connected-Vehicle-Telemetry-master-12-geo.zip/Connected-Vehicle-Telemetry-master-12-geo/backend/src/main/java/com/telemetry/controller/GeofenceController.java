package com.telemetry.controller;

import com.telemetry.dto.geo.CreateGeofenceRequest;
import com.telemetry.dto.geo.GeofenceDto;
import com.telemetry.dto.geo.GeofenceEventDto;
import com.telemetry.entity.User;
import com.telemetry.service.GeofenceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/geofences")
@RequiredArgsConstructor
public class GeofenceController {

    private final GeofenceService service;

    @GetMapping
    public List<GeofenceDto> list(@AuthenticationPrincipal User current) {
        return service.list(current);
    }

    @GetMapping("/{id}")
    public ResponseEntity<GeofenceDto> get(@PathVariable Long id,
                                           @AuthenticationPrincipal User current) {
        return ResponseEntity.ok(service.get(id, current));
    }

    @PostMapping
    public ResponseEntity<GeofenceDto> create(@Valid @RequestBody CreateGeofenceRequest req,
                                              @AuthenticationPrincipal User current) {
        return ResponseEntity.ok(service.create(req, current));
    }

    @PutMapping("/{id}")
    public ResponseEntity<GeofenceDto> update(@PathVariable Long id,
                                              @Valid @RequestBody CreateGeofenceRequest req,
                                              @AuthenticationPrincipal User current) {
        return ResponseEntity.ok(service.update(id, req, current));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                       @AuthenticationPrincipal User current) {
        service.delete(id, current);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/events")
    public List<GeofenceEventDto> events(@AuthenticationPrincipal User current) {
        return service.recentEventsForCurrentUser(current);
    }

    @GetMapping("/events/unacknowledged-count")
    public Map<String, Long> unacknowledged(@AuthenticationPrincipal User current) {
        return Map.of("count", service.unacknowledgedCount(current));
    }

    @PostMapping("/events/{id}/ack")
    public ResponseEntity<Void> ack(@PathVariable Long id,
                                    @AuthenticationPrincipal User current) {
        service.acknowledge(id, current);
        return ResponseEntity.noContent().build();
    }
}
