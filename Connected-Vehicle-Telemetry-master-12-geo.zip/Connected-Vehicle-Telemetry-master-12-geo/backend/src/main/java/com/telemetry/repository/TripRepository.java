package com.telemetry.repository;

import com.telemetry.entity.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {

    List<Trip> findByVehicleidOrderByStartTsDesc(Long vehicleid);

    @Query("SELECT t FROM Trip t WHERE t.vehicleid = :vid AND t.startTs BETWEEN :from AND :to ORDER BY t.startTs DESC")
    List<Trip> findInRange(@Param("vid") Long vehicleId,
                           @Param("from") Instant from,
                           @Param("to") Instant to);

    @Query("SELECT MAX(t.endTs) FROM Trip t WHERE t.vehicleid = :vid")
    Optional<Instant> findLastEndTs(@Param("vid") Long vehicleId);

    void deleteByVehicleid(Long vehicleid);
}
