package com.telemetry.dto.geo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Full trip payload: metadata plus the time-ordered sequence of points and
 * an optional snapped-to-road geometry (GeoJSON LineString) from OSRM.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TripDetailDto {
    private TripDto trip;
    private List<TripPointDto> points;
    /** GeoJSON LineString coordinates from OSRM, [[lon,lat], ...]. Null if not snapped. */
    private List<double[]> snappedRoute;
}
