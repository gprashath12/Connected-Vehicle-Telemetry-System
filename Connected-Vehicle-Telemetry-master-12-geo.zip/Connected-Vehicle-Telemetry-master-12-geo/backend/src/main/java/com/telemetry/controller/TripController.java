package com.telemetry.controller;

import com.telemetry.dto.geo.TripDetailDto;
import com.telemetry.dto.geo.TripDto;
import com.telemetry.entity.User;
import com.telemetry.service.TripService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips")
@RequiredArgsConstructor
public class TripController {

    private final TripService service;

    /** All trips for a vehicle, optionally bounded by from/to (epoch ms). */
    @GetMapping("/vehicle/{vehicleId}")
    public List<TripDto> listForVehicle(@PathVariable Long vehicleId,
                                        @RequestParam(required = false) Long from,
                                        @RequestParam(required = false) Long to,
                                        @AuthenticationPrincipal User current) {
        if (from != null && to != null) {
            return service.listInRange(vehicleId, from, to, current);
        }
        return service.listForVehicle(vehicleId, current);
    }

    /** Full trip detail with point sequence and (optional) snapped route. */
    @GetMapping("/{id}")
    public ResponseEntity<TripDetailDto> detail(@PathVariable Long id,
                                                @AuthenticationPrincipal User current) {
        return ResponseEntity.ok(service.getTripDetail(id, current));
    }

    /** Force a snap-to-road refresh for one trip. No-op if OSRM is disabled. */
    @PostMapping("/{id}/snap")
    public ResponseEntity<TripDetailDto> snap(@PathVariable Long id,
                                              @AuthenticationPrincipal User current) {
        return ResponseEntity.ok(service.snapTrip(id, current));
    }

    /** Admin/maintenance: rebuild trips for a single vehicle from raw readings. */
    @PostMapping("/vehicle/{vehicleId}/rebuild")
    public ResponseEntity<?> rebuild(@PathVariable Long vehicleId,
                                     @AuthenticationPrincipal User current) {
        // Ownership check happens via listForVehicle's path; rebuild is allowed
        // for anyone who can already see the vehicle.
        service.listForVehicle(vehicleId, current); // throws on access denial
        int n = service.rebuildForVehicle(vehicleId);
        return ResponseEntity.ok(java.util.Map.of("rebuilt", n));
    }
}
