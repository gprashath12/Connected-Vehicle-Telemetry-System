package com.telemetry.exception;

public class TripNotFoundException extends RuntimeException {
    public TripNotFoundException() { super("Trip not found"); }
}
