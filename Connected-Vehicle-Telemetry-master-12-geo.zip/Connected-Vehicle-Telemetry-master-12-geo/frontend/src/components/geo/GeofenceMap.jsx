import { useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Polygon, Tooltip, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const CATEGORY_DEFAULT_COLOR = {
  DEPOT: '#0ea5e9',
  CUSTOMER_SITE: '#10b981',
  RESTRICTED: '#ef4444',
  CUSTOM: '#2563eb',
};

export default function GeofenceMap({ fences = [], height = 420, selectedId, onSelect }) {
  const center = useMemo(() => {
    const all = fences.flatMap((f) => f.polygon || []);
    if (!all.length) return [12.97, 77.59];
    const lat = all.reduce((s, p) => s + p[0], 0) / all.length;
    const lon = all.reduce((s, p) => s + p[1], 0) / all.length;
    return [lat, lon];
  }, [fences]);

  const bounds = useMemo(() => {
    const all = fences.flatMap((f) => f.polygon || []);
    if (all.length < 2) return null;
    return L.latLngBounds(all.map(([lat, lon]) => [lat, lon]));
  }, [fences]);

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
      <MapContainer
        center={center}
        zoom={fences.length ? 12 : 5}
        style={{ height: `${height}px`, width: '100%' }}
        scrollWheelZoom
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {bounds && <FitBounds bounds={bounds} />}

        {fences.map((g) => {
          const isSelected = selectedId === g.geofenceId;
          const color = g.color || CATEGORY_DEFAULT_COLOR[g.category] || '#2563eb';
          return (
            <Polygon
              key={g.geofenceId}
              positions={g.polygon}
              pathOptions={{
                color,
                fillOpacity: isSelected ? 0.35 : 0.15,
                weight: isSelected ? 3 : 2,
                opacity: g.enabled ? 1 : 0.4,
                dashArray: g.enabled ? null : '4 6',
              }}
              eventHandlers={{ click: () => onSelect?.(g.geofenceId) }}
            >
              <Tooltip sticky>
                <div className="text-xs">
                  <div className="font-semibold">{g.name}</div>
                  <div className="text-slate-500">{g.category}</div>
                  {!g.enabled && <div className="text-rose-500">Disabled</div>}
                </div>
              </Tooltip>
            </Polygon>
          );
        })}
      </MapContainer>
    </div>
  );
}

/** Fits the map viewport to the given LatLngBounds when it changes. */
function FitBounds({ bounds }) {
  const map = useMap();
  useEffect(() => {
    if (bounds && bounds.isValid()) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    }
  }, [map, bounds]);
  return null;
}
