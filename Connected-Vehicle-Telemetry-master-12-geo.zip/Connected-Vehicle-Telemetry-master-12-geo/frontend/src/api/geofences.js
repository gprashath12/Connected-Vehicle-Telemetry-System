import { apiClient } from './client';

// GET /api/geofences
export async function fetchGeofences() {
  const { data } = await apiClient.get('/geofences');
  return data;
}

// GET /api/geofences/{id}
export async function fetchGeofence(id) {
  const { data } = await apiClient.get(`/geofences/${id}`);
  return data;
}

// POST /api/geofences
export async function createGeofence(payload) {
  const { data } = await apiClient.post('/geofences', payload);
  return data;
}

// PUT /api/geofences/{id}
export async function updateGeofence(id, payload) {
  const { data } = await apiClient.put(`/geofences/${id}`, payload);
  return data;
}

// DELETE /api/geofences/{id}
export async function deleteGeofence(id) {
  await apiClient.delete(`/geofences/${id}`);
}

// GET /api/geofences/events
export async function fetchGeofenceEvents() {
  const { data } = await apiClient.get('/geofences/events');
  return data;
}

// GET /api/geofences/events/unacknowledged-count
export async function fetchUnacknowledgedCount() {
  const { data } = await apiClient.get('/geofences/events/unacknowledged-count');
  return data.count;
}

// POST /api/geofences/events/{id}/ack
export async function acknowledgeEvent(id) {
  await apiClient.post(`/geofences/events/${id}/ack`);
}
