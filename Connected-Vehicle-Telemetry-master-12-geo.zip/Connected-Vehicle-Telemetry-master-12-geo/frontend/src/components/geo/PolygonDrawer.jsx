import { useEffect, useMemo, useState } from 'react';
import {
  MapContainer,
  TileLayer,
  Polygon,
  Polyline,
  CircleMarker,
  useMap,
  useMapEvents,
} from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

/**
 * Polygon drawing component.
 *
 * DESIGN NOTES:
 *   - vertices is purely LOCAL state — the parent does NOT control it. The parent
 *     only provides an initial value and receives updates via onChange.
 *   - To reinitialise (e.g. switching from create→edit), mount with a different key.
 *   - The previous pattern of syncing `value` back via useEffect caused a race:
 *     every onChange triggered the parent to pass a new array reference, which
 *     fired the effect and could reset or flicker the vertex list.
 */
export default function PolygonDrawer({
  value = [],
  onChange,
  color = '#2563eb',
  height = 420,
  initialCenter = [12.97, 77.59],
  initialZoom = 12,
  existingFences = [],
}) {
  // Initialised ONCE from value — never synced back from parent after mount.
  const [vertices, setVertices] = useState(() => (Array.isArray(value) ? [...value] : []));

  const handleAdd = (lat, lon) => {
    const next = [...vertices, [lat, lon]];
    setVertices(next);
    onChange?.(next);
  };

  const handleUndo = () => {
    const next = vertices.slice(0, -1);
    setVertices(next);
    onChange?.(next);
  };

  const handleClear = () => {
    setVertices([]);
    onChange?.([]);
  };

  // On mount, fit the map to the initial polygon (edit mode) or existing fences.
  const fitBounds = useMemo(() => {
    const pts =
      value.length >= 3
        ? value
        : existingFences.flatMap((f) => f.polygon || []);
    if (pts.length < 2) return null;
    const b = L.latLngBounds(pts.map(([la, lo]) => [la, lo]));
    return b.isValid() ? b : null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // intentionally empty — run once on mount

  return (
    <div className="relative rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
      <MapContainer
        center={initialCenter}
        zoom={initialZoom}
        style={{ height: `${height}px`, width: '100%' }}
        scrollWheelZoom
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* Existing fences shown as faint dashed outlines for context */}
        {existingFences.map((g) => (
          <Polygon
            key={g.geofenceId}
            positions={g.polygon}
            pathOptions={{
              color: g.color || '#94a3b8',
              fillOpacity: 0.05,
              opacity: 0.5,
              dashArray: '4 6',
              weight: 1.5,
            }}
          />
        ))}

        {/* In-progress shape */}
        {vertices.length === 2 && (
          <Polyline positions={vertices} pathOptions={{ color, weight: 2, dashArray: '4 4' }} />
        )}
        {vertices.length >= 3 && (
          <Polygon
            positions={vertices}
            pathOptions={{
              color,
              fillColor: color,
              fillOpacity: 0.2,
              weight: 2.5,
              opacity: 1,
            }}
          />
        )}

        {/* Vertex dots */}
        {vertices.map((v, i) => (
          <CircleMarker
            key={i}
            center={v}
            radius={6}
            pathOptions={{
              color,
              fillColor: '#ffffff',
              fillOpacity: 1,
              weight: 2,
            }}
          />
        ))}

        {fitBounds && <FitBoundsOnce bounds={fitBounds} />}
        <ClickHandler onAdd={handleAdd} />
      </MapContainer>

      {/* Controls overlay (top-right) */}
      <div className="absolute top-3 right-3 z-[1000] flex flex-col gap-1.5 bg-white/95 dark:bg-slate-800/95 backdrop-blur border border-slate-200 dark:border-slate-700 rounded-lg p-2 shadow-lg text-xs min-w-[90px]">
        <div className="text-slate-700 dark:text-slate-200 font-semibold px-1 pb-1 border-b border-slate-200 dark:border-slate-700 text-center">
          {vertices.length} point{vertices.length === 1 ? '' : 's'}
        </div>
        <button
          type="button"
          onClick={handleUndo}
          disabled={!vertices.length}
          className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          Undo last
        </button>
        <button
          type="button"
          onClick={handleClear}
          disabled={!vertices.length}
          className="px-2 py-1 rounded bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300 hover:bg-rose-200 dark:hover:bg-rose-900/60 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          Clear all
        </button>
      </div>

      {/* Instructions (bottom-left) */}
      <div className="absolute bottom-3 left-3 z-[1000] bg-white/95 dark:bg-slate-800/95 backdrop-blur border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 shadow text-xs text-slate-600 dark:text-slate-300 max-w-xs">
        {vertices.length < 3
          ? `Click the map to add vertices (${3 - vertices.length} more needed)`
          : `${vertices.length} vertices — polygon ready. Add more or save.`}
      </div>
    </div>
  );
}

/** Registers a map click → adds a vertex. Uses a ref to avoid stale closures. */
function ClickHandler({ onAdd }) {
  useMapEvents({
    click(e) {
      onAdd(
        Math.round(e.latlng.lat * 100000) / 100000,
        Math.round(e.latlng.lng * 100000) / 100000,
      );
    },
  });
  return null;
}

/** Fits the map to `bounds` once on mount. */
function FitBoundsOnce({ bounds }) {
  const map = useMap();
  useEffect(() => {
    if (bounds?.isValid()) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}
