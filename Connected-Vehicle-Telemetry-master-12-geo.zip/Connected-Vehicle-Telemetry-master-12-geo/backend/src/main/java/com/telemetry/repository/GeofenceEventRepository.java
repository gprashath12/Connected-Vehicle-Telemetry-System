package com.telemetry.repository;

import com.telemetry.entity.GeofenceEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface GeofenceEventRepository extends JpaRepository<GeofenceEvent, Long> {

    @Query("SELECT e FROM GeofenceEvent e WHERE e.vehicleid IN :vehicleIds ORDER BY e.ts DESC")
    List<GeofenceEvent> findRecentByVehicles(@Param("vehicleIds") List<Long> vehicleIds);

    @Query("SELECT e FROM GeofenceEvent e WHERE e.vehicleid = :vid AND e.ts BETWEEN :from AND :to ORDER BY e.ts DESC")
    List<GeofenceEvent> findForVehicleInRange(
            @Param("vid") Long vehicleId, @Param("from") Instant from, @Param("to") Instant to);

    @Query("SELECT e FROM GeofenceEvent e WHERE e.geofenceId = :gid ORDER BY e.ts DESC")
    List<GeofenceEvent> findByGeofence(@Param("gid") Long geofenceId);

    @Query("SELECT e FROM GeofenceEvent e WHERE e.vehicleid = :vid ORDER BY e.ts DESC LIMIT 1")
    Optional<GeofenceEvent> findLatestForVehicle(@Param("vid") Long vehicleId);

    @Query("SELECT COUNT(e) FROM GeofenceEvent e WHERE e.vehicleid IN :vehicleIds AND e.acknowledged = false")
    long countUnacknowledged(@Param("vehicleIds") List<Long> vehicleIds);

    void deleteByGeofenceId(Long geofenceId);
}
