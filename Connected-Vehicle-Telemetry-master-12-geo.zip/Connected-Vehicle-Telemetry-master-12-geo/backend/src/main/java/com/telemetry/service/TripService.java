package com.telemetry.service;

import com.telemetry.dto.geo.TripDetailDto;
import com.telemetry.dto.geo.TripDto;
import com.telemetry.dto.geo.TripPointDto;
import com.telemetry.entity.Role;
import com.telemetry.entity.Trip;
import com.telemetry.entity.User;
import com.telemetry.entity.Vehicle;
import com.telemetry.entity.VehicleReading;
import com.telemetry.exception.TripNotFoundException;
import com.telemetry.exception.VehicleAccessDeniedException;
import com.telemetry.exception.VehicleNotFoundException;
import com.telemetry.repository.TripRepository;
import com.telemetry.repository.VehicleReadingRepository;
import com.telemetry.repository.VehicleRepository;
import com.telemetry.util.DistanceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Trip = a contiguous run of readings where successive timestamps are no more than
 * `gap-minutes` apart. The simulator stops writing rows during OFF periods, so a
 * gap in the time series naturally signals ignition off.
 *
 * Trips are recomputed incrementally: each rebuild only looks at readings newer
 * than the last completed trip.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class TripService {

    private final TripRepository tripRepo;
    private final VehicleRepository vehicleRepo;
    private final VehicleReadingRepository readingRepo;
    private final OsrmClient osrmClient;

    @Value("${telemetry.trips.gap-minutes:10}")
    private int gapMinutes;

    @Value("${telemetry.trips.min-distance-km:0.3}")
    private double minDistanceKm;

    @Value("${telemetry.trips.rebuild-enabled:true}")
    private boolean rebuildEnabled;

    @Value("${telemetry.trips.snap-on-rebuild:false}")
    private boolean snapOnRebuild;

    /* ───────────────── Public API ───────────────── */

    public List<TripDto> listForVehicle(Long vehicleId, User current) {
        ensureAuthorized(vehicleId, current);
        return tripRepo.findByVehicleidOrderByStartTsDesc(vehicleId).stream()
                .map(TripDto::from).toList();
    }

    public List<TripDto> listInRange(Long vehicleId, long fromMs, long toMs, User current) {
        ensureAuthorized(vehicleId, current);
        return tripRepo.findInRange(vehicleId, Instant.ofEpochMilli(fromMs), Instant.ofEpochMilli(toMs))
                .stream().map(TripDto::from).toList();
    }

    public TripDetailDto getTripDetail(Long tripId, User current) {
        Trip t = tripRepo.findById(tripId).orElseThrow(TripNotFoundException::new);
        ensureAuthorized(t.getVehicleid(), current);
        List<VehicleReading> readings = readingRepo
                .findByVehicleidAndTsBetweenOrderByTsAsc(t.getVehicleid(), t.getStartTs(), t.getEndTs());
        List<TripPointDto> points = readings.stream().map(r -> new TripPointDto(
                r.getTs().toEpochMilli(),
                nz(r.getLat()), nz(r.getLon()),
                nz(r.getSpeed()), nz(r.getEngineTemp())
        )).toList();

        List<double[]> snapped = osrmClient.parseGeometry(t.getSnappedGeometry());
        return new TripDetailDto(TripDto.from(t), points, snapped);
    }

    /** Re-runs OSRM snap for a trip on demand. */
    @Transactional
    public TripDetailDto snapTrip(Long tripId, User current) {
        Trip t = tripRepo.findById(tripId).orElseThrow(TripNotFoundException::new);
        ensureAuthorized(t.getVehicleid(), current);
        List<VehicleReading> readings = readingRepo
                .findByVehicleidAndTsBetweenOrderByTsAsc(t.getVehicleid(), t.getStartTs(), t.getEndTs());
        String geom = osrmClient.snapToRoad(readings);
        if (geom != null) {
            t.setSnappedGeometry(geom);
            tripRepo.save(t);
        }
        return getTripDetail(tripId, current);
    }

    /* ───────────────── Scheduled rebuild ───────────────── */

    /**
     * Walks every vehicle and appends any new completed trips since the last
     * known end-timestamp. Runs every 5 minutes by default.
     */
    @Scheduled(fixedRateString = "${telemetry.trips.rebuild-rate-ms:300000}", initialDelay = 30_000)
    @Transactional
    public void rebuildAll() {
        if (!rebuildEnabled) return;
        for (Vehicle v : vehicleRepo.findAll()) {
            rebuildForVehicle(v.getVehicleid());
        }
    }

    @Transactional
    public int rebuildForVehicle(Long vehicleId) {
        Instant since = tripRepo.findLastEndTs(vehicleId).orElse(Instant.EPOCH);
        // We always look back a little to allow a trip ending later to be finalised.
        Instant readSince = since.minusSeconds(60L * gapMinutes);
        List<VehicleReading> readings = readingRepo
                .findByVehicleidAndTsBetweenOrderByTsAsc(vehicleId, readSince, Instant.now());
        if (readings.size() < 2) return 0;

        long gapMs = gapMinutes * 60_000L;
        List<List<VehicleReading>> segments = new ArrayList<>();
        List<VehicleReading> cur = new ArrayList<>();
        cur.add(readings.get(0));
        for (int i = 1; i < readings.size(); i++) {
            long delta = readings.get(i).getTs().toEpochMilli() - readings.get(i - 1).getTs().toEpochMilli();
            if (delta > gapMs) {
                if (cur.size() > 1) segments.add(cur);
                cur = new ArrayList<>();
            }
            cur.add(readings.get(i));
        }
        // We deliberately DROP the last segment if it might still be ongoing
        // (last reading is too recent). It'll be picked up on the next rebuild.
        long cutoff = System.currentTimeMillis() - gapMs;
        if (cur.size() > 1 && cur.get(cur.size() - 1).getTs().toEpochMilli() < cutoff) {
            segments.add(cur);
        }

        int saved = 0;
        for (List<VehicleReading> seg : segments) {
            Trip t = buildTrip(vehicleId, seg);
            if (t == null) continue;
            // Skip if this trip is older than what we already have stored — i.e. it
            // was already saved on a previous run.
            if (!t.getStartTs().isAfter(since)) continue;
            if (snapOnRebuild) {
                t.setSnappedGeometry(osrmClient.snapToRoad(seg));
            }
            tripRepo.save(t);
            saved++;
        }
        if (saved > 0 && log.isInfoEnabled()) {
            log.info("Rebuilt {} new trip(s) for vehicle {}", saved, vehicleId);
        }
        return saved;
    }

    /* ───────────────── Helpers ───────────────── */

    private Trip buildTrip(Long vid, List<VehicleReading> seg) {
        if (seg.size() < 2) return null;
        double dist = DistanceUtil.totalDistanceKm(seg);
        if (dist < minDistanceKm) return null; // ignore micro-trips (drifting GPS while parked)

        double maxSpeed = 0, sumMoving = 0;
        int movingCount = 0, idleCount = 0;
        for (VehicleReading r : seg) {
            double s = nz(r.getSpeed());
            if (s > maxSpeed) maxSpeed = s;
            if (s > 1) { sumMoving += s; movingCount++; } else { idleCount++; }
        }
        long stepMs = seg.size() > 1
                ? (seg.get(1).getTs().toEpochMilli() - seg.get(0).getTs().toEpochMilli())
                : 60_000L;
        int idleMin = (int) Math.round((idleCount * stepMs) / 60_000.0);

        Trip t = new Trip();
        t.setVehicleid(vid);
        t.setStartTs(seg.get(0).getTs());
        t.setEndTs(seg.get(seg.size() - 1).getTs());
        t.setStartLat(seg.get(0).getLat());
        t.setStartLon(seg.get(0).getLon());
        t.setEndLat(seg.get(seg.size() - 1).getLat());
        t.setEndLon(seg.get(seg.size() - 1).getLon());
        t.setDistanceKm(round1(dist));
        t.setMaxSpeed(round1(maxSpeed));
        t.setAvgSpeed(movingCount > 0 ? round1(sumMoving / movingCount) : 0.0);
        t.setIdleMinutes(idleMin);
        t.setPointCount(seg.size());
        return t;
    }

    private void ensureAuthorized(Long vehicleId, User current) {
        Vehicle v = vehicleRepo.findById(vehicleId).orElseThrow(VehicleNotFoundException::new);
        if (current.getRole() == Role.ADMIN) return;
        Long ownerId = v.getOwnerId();
        if (ownerId == null || !ownerId.equals(current.getUserId())) {
            throw new VehicleAccessDeniedException();
        }
    }

    private static double nz(Double d) { return d == null ? 0.0 : d; }
    private static double round1(double d) { return Math.round(d * 10.0) / 10.0; }

    /** Used by DataSeeder to force a one-shot rebuild after seeding. */
    public void seedRebuild() {
        if (!rebuildEnabled) return;
        for (Vehicle v : vehicleRepo.findAll()) {
            // For seeded data we don't want the "drop ongoing trip" guard to skip
            // the most recent segment — bypass it by calling the helper directly.
            rebuildForVehicleIncludingTail(v.getVehicleid());
        }
    }

    @Transactional
    public void rebuildForVehicleIncludingTail(Long vehicleId) {
        List<VehicleReading> readings = readingRepo
                .findByVehicleidAndTsBetweenOrderByTsAsc(vehicleId, Instant.EPOCH, Instant.now());
        if (readings.size() < 2) return;

        long gapMs = gapMinutes * 60_000L;
        List<List<VehicleReading>> segments = new ArrayList<>();
        List<VehicleReading> cur = new ArrayList<>();
        cur.add(readings.get(0));
        for (int i = 1; i < readings.size(); i++) {
            long delta = readings.get(i).getTs().toEpochMilli() - readings.get(i - 1).getTs().toEpochMilli();
            if (delta > gapMs) {
                if (cur.size() > 1) segments.add(cur);
                cur = new ArrayList<>();
            }
            cur.add(readings.get(i));
        }
        if (cur.size() > 1) segments.add(cur);

        for (List<VehicleReading> seg : segments) {
            Trip t = buildTrip(vehicleId, seg);
            if (t != null) tripRepo.save(t);
        }
    }
}
