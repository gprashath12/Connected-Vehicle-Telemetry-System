import { useMutation, useQueryClient } from '@tanstack/react-query';
import { LogIn, LogOut, Check } from 'lucide-react';
import { acknowledgeEvent } from '../../api/geofences';
import { formatDistanceToNow } from '../../lib/timeAgo';

const TYPE_STYLES = {
  ENTRY: {
    bg: 'bg-emerald-50 dark:bg-emerald-900/30',
    text: 'text-emerald-700 dark:text-emerald-300',
    Icon: LogIn,
    label: 'Entry',
  },
  EXIT: {
    bg: 'bg-amber-50 dark:bg-amber-900/30',
    text: 'text-amber-700 dark:text-amber-300',
    Icon: LogOut,
    label: 'Exit',
  },
};

export default function GeofenceEventsTable({ events = [], compact = false, limit }) {
  const queryClient = useQueryClient();

  const ackMutation = useMutation({
    mutationFn: acknowledgeEvent,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['geofence-events'] });
      queryClient.invalidateQueries({ queryKey: ['geofence-unack-count'] });
    },
  });

  const rows = limit ? events.slice(0, limit) : events;

  if (!rows.length) {
    return (
      <div className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">
        No geofence events yet. Once a vehicle enters or leaves one of your fences, it will show up here.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
          <tr>
            <th className="text-left font-medium py-2 pr-3">Type</th>
            <th className="text-left font-medium py-2 pr-3">Vehicle</th>
            <th className="text-left font-medium py-2 pr-3">Geofence</th>
            {!compact && <th className="text-left font-medium py-2 pr-3">Speed</th>}
            <th className="text-left font-medium py-2 pr-3">When</th>
            <th className="text-right font-medium py-2 pl-3">Action</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map((e) => {
            const style = TYPE_STYLES[e.eventType] ?? TYPE_STYLES.ENTRY;
            const { Icon } = style;
            return (
              <tr
                key={e.eventId}
                className={e.acknowledged ? 'opacity-60' : ''}
              >
                <td className="py-2 pr-3">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${style.bg} ${style.text}`}
                  >
                    <Icon className="h-3 w-3" />
                    {style.label}
                  </span>
                </td>
                <td className="py-2 pr-3 text-slate-700 dark:text-slate-200">
                  <div className="font-medium">{e.vehicleName || `#${e.vehicleId}`}</div>
                  {e.vehicleCode && (
                    <div className="text-xs text-slate-500 dark:text-slate-400">{e.vehicleCode}</div>
                  )}
                </td>
                <td className="py-2 pr-3 text-slate-700 dark:text-slate-200">
                  <div className="font-medium">{e.geofenceName || `#${e.geofenceId}`}</div>
                  {e.category && (
                    <div className="text-xs text-slate-500 dark:text-slate-400">{e.category}</div>
                  )}
                </td>
                {!compact && (
                  <td className="py-2 pr-3 text-slate-700 dark:text-slate-200 tabular-nums">
                    {e.speed != null ? `${e.speed.toFixed(0)} km/h` : '—'}
                  </td>
                )}
                <td className="py-2 pr-3 text-slate-600 dark:text-slate-300">
                  {formatDistanceToNow(new Date(e.ts))}
                </td>
                <td className="py-2 pl-3 text-right">
                  {e.acknowledged ? (
                    <span className="text-xs text-slate-400 dark:text-slate-500">Acknowledged</span>
                  ) : (
                    <button
                      onClick={() => ackMutation.mutate(e.eventId)}
                      disabled={ackMutation.isPending}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs bg-brand-50 text-brand-700 hover:bg-brand-100 dark:bg-brand-500/15 dark:text-brand-300 dark:hover:bg-brand-500/25 disabled:opacity-50"
                    >
                      <Check className="h-3 w-3" /> Ack
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
