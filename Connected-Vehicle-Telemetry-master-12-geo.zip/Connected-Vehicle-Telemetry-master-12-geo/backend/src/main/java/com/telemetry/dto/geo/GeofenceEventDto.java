package com.telemetry.dto.geo;

import com.telemetry.entity.GeofenceEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GeofenceEventDto {
    private Long eventId;
    private Long vehicleId;
    private String vehicleName;
    private String vehicleCode;
    private Long geofenceId;
    private String geofenceName;
    private String category;
    private String eventType;   // ENTRY | EXIT
    private Double lat;
    private Double lon;
    private Double speed;
    private Instant ts;
    private boolean acknowledged;

    public static GeofenceEventDto from(GeofenceEvent e) {
        GeofenceEventDto d = new GeofenceEventDto();
        d.eventId       = e.getEventId();
        d.vehicleId     = e.getVehicleid();
        d.geofenceId    = e.getGeofenceId();
        d.eventType     = e.getEventType().name();
        d.lat           = e.getLat();
        d.lon           = e.getLon();
        d.speed         = e.getSpeed();
        d.ts            = e.getTs();
        d.acknowledged  = e.isAcknowledged();
        return d;
    }
}
