package com.telemetry.dto.geo;

import com.telemetry.entity.Geofence;
import com.telemetry.util.GeoMath;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GeofenceDto {
    private Long geofenceId;
    private String name;
    private String description;
    private String category;
    private String color;
    private List<double[]> polygon;   // [[lat,lon],...]
    private boolean enabled;
    private boolean alertOnEntry;
    private boolean alertOnExit;
    private Long ownerId;
    private Instant createdAt;

    public static GeofenceDto from(Geofence g) {
        GeofenceDto d = new GeofenceDto();
        d.geofenceId    = g.getGeofenceId();
        d.name          = g.getName();
        d.description   = g.getDescription();
        d.category      = g.getCategory().name();
        d.color         = g.getColor();
        d.polygon       = GeoMath.parsePolygon(g.getPolygonJson());
        d.enabled       = g.isEnabled();
        d.alertOnEntry  = g.isAlertOnEntry();
        d.alertOnExit   = g.isAlertOnExit();
        d.ownerId       = g.getOwnerId();
        d.createdAt     = g.getCreatedAt();
        return d;
    }
}
