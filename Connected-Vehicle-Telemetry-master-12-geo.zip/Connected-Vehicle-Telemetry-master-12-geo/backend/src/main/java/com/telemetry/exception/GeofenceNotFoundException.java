package com.telemetry.exception;

public class GeofenceNotFoundException extends RuntimeException {
    public GeofenceNotFoundException() { super("Geofence not found"); }
}
