package com.telemetry.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * A trip is a contiguous run of readings for one vehicle, terminated by either
 * an OFF gap (no rows for N minutes) or a long idle stretch.
 *
 * Trips are derived data — recomputed from {@link VehicleReading}. The TripService
 * rebuilds them on a schedule and after seeding.
 */
@Entity
@Table(name = "trip", indexes = {
        @Index(name = "idx_trip_vehicle_start", columnList = "vehicleid,start_ts"),
        @Index(name = "idx_trip_start_ts", columnList = "start_ts")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "trip_id")
    private Long tripId;

    @Column(name = "vehicleid", nullable = false)
    private Long vehicleid;

    @Column(name = "start_ts", nullable = false)
    private Instant startTs;

    @Column(name = "end_ts", nullable = false)
    private Instant endTs;

    @Column(name = "start_lat") private Double startLat;
    @Column(name = "start_lon") private Double startLon;
    @Column(name = "end_lat")   private Double endLat;
    @Column(name = "end_lon")   private Double endLon;

    @Column(name = "distance_km") private Double distanceKm;
    @Column(name = "max_speed")   private Double maxSpeed;
    @Column(name = "avg_speed")   private Double avgSpeed;
    @Column(name = "idle_minutes") private Integer idleMinutes;
    @Column(name = "point_count") private Integer pointCount;

    /**
     * Optional GeoJSON LineString of OSRM-snapped road geometry.
     * Lazily populated by OsrmClient when snap-to-road is enabled.
     */
    @Lob
    @Column(name = "snapped_geometry", columnDefinition = "TEXT")
    private String snappedGeometry;
}
