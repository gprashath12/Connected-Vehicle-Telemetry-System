package com.telemetry.repository;

import com.telemetry.entity.Geofence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GeofenceRepository extends JpaRepository<Geofence, Long> {

    @Query("SELECT g FROM Geofence g WHERE g.owner.userId = :ownerId ORDER BY g.geofenceId ASC")
    List<Geofence> findByOwnerOrdered(@Param("ownerId") Long ownerId);

    @Query("SELECT g FROM Geofence g WHERE g.owner.userId = :ownerId AND g.enabled = true")
    List<Geofence> findEnabledByOwner(@Param("ownerId") Long ownerId);

    @Query("SELECT g FROM Geofence g WHERE g.enabled = true")
    List<Geofence> findAllEnabled();
}
