package com.telemetry.dto.geo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TripPointDto {
    private long ts;            // epoch millis
    private double lat;
    private double lon;
    private double speed;
    private double engineTemp;
}
