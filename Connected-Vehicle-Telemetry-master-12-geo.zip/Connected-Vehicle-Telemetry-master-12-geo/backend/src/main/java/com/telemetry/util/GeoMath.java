package com.telemetry.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telemetry.entity.Geofence;

import java.util.List;

/**
 * Static geometry helpers. No JTS dependency — keeps the build slim.
 * Polygons are arrays of [lat, lon] vertices, implicitly closed.
 */
public final class GeoMath {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private GeoMath() {}

    /** Parse polygon JSON into a list of {lat, lon} pairs. */
    public static List<double[]> parsePolygon(String json) {
        try {
            List<List<Double>> raw = MAPPER.readValue(
                    json, new TypeReference<List<List<Double>>>() {});
            return raw.stream()
                    .filter(p -> p.size() >= 2)
                    .map(p -> new double[]{ p.get(0), p.get(1) })
                    .toList();
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid polygon JSON", e);
        }
    }

    /** Serialise a polygon back to JSON. */
    public static String toPolygonJson(List<double[]> verts) {
        try {
            List<List<Double>> raw = verts.stream()
                    .map(p -> List.of(p[0], p[1]))
                    .toList();
            return MAPPER.writeValueAsString(raw);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to serialise polygon", e);
        }
    }

    /**
     * Ray-casting point-in-polygon test. Treats coordinates as planar; for
     * the geofence sizes we deal with (a few km) the spherical correction is
     * not material. Polygon is implicitly closed.
     */
    public static boolean pointInPolygon(double lat, double lon, List<double[]> verts) {
        if (verts == null || verts.size() < 3) return false;
        boolean inside = false;
        int n = verts.size();
        for (int i = 0, j = n - 1; i < n; j = i++) {
            double yi = verts.get(i)[0], xi = verts.get(i)[1];
            double yj = verts.get(j)[0], xj = verts.get(j)[1];
            boolean intersect = ((yi > lat) != (yj > lat)) &&
                    (lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-12) + xi);
            if (intersect) inside = !inside;
        }
        return inside;
    }

    /** Recompute and assign min/max lat/lon onto a geofence from its polygon JSON. */
    public static void recomputeBounds(Geofence g) {
        List<double[]> verts = parsePolygon(g.getPolygonJson());
        double minLat = Double.MAX_VALUE, maxLat = -Double.MAX_VALUE;
        double minLon = Double.MAX_VALUE, maxLon = -Double.MAX_VALUE;
        for (double[] v : verts) {
            if (v[0] < minLat) minLat = v[0];
            if (v[0] > maxLat) maxLat = v[0];
            if (v[1] < minLon) minLon = v[1];
            if (v[1] > maxLon) maxLon = v[1];
        }
        g.setMinLat(minLat); g.setMaxLat(maxLat);
        g.setMinLon(minLon); g.setMaxLon(maxLon);
    }

    /** Quick reject test using the cached bounding box. */
    public static boolean inBoundingBox(double lat, double lon, Geofence g) {
        if (g.getMinLat() == null) return true; // no bbox cached — fall through to polygon test
        return lat >= g.getMinLat() && lat <= g.getMaxLat()
            && lon >= g.getMinLon() && lon <= g.getMaxLon();
    }
}
