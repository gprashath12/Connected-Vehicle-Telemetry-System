package com.telemetry.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * A named polygonal region (depot, customer site, restricted zone) scoped to an owner.
 *
 * Vertices are stored as JSON text in `polygon_json` to keep schema portable
 * (MySQL JSON column type works, but plain TEXT is simpler and works everywhere).
 * Format: [[lat, lon], [lat, lon], ...] — first and last point need not match,
 * polygon is implicitly closed.
 */
@Entity
@Table(name = "geofence", indexes = {
        @Index(name = "idx_geofence_owner", columnList = "owner_id"),
        @Index(name = "idx_geofence_enabled", columnList = "enabled")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Geofence {

    public enum Category { DEPOT, CUSTOMER_SITE, RESTRICTED, CUSTOM }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "geofence_id")
    private Long geofenceId;

    @Column(name = "name", nullable = false, length = 120)
    private String name;

    @Column(name = "description", length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "category", length = 32, nullable = false)
    private Category category = Category.CUSTOM;

    /** Hex color for map rendering. */
    @Column(name = "color", length = 9)
    private String color = "#2563eb";

    /** JSON: [[lat,lon],[lat,lon],...] */
    @Lob
    @Column(name = "polygon_json", nullable = false, columnDefinition = "TEXT")
    private String polygonJson;

    /** Bounding-box cache for fast pre-filter. */
    @Column(name = "min_lat") private Double minLat;
    @Column(name = "max_lat") private Double maxLat;
    @Column(name = "min_lon") private Double minLon;
    @Column(name = "max_lon") private Double maxLon;

    @Column(name = "enabled", nullable = false)
    private boolean enabled = true;

    /** Whether entry/exit events should generate notifications. */
    @Column(name = "alert_on_entry", nullable = false)
    private boolean alertOnEntry = true;

    @Column(name = "alert_on_exit", nullable = false)
    private boolean alertOnExit = true;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "owner_id", nullable = false)
    @JsonIgnore
    private User owner;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Transient
    public Long getOwnerId() {
        return owner != null ? owner.getUserId() : null;
    }
}
