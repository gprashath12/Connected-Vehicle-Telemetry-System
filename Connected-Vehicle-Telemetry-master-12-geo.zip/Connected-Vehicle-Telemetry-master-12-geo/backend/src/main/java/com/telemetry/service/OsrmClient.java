package com.telemetry.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telemetry.entity.VehicleReading;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Optional snap-to-road service backed by OSRM (Open Source Routing Machine).
 *
 *   telemetry.osrm.enabled=false          (default — disabled, no network calls)
 *   telemetry.osrm.base-url=https://router.project-osrm.org
 *
 * The public OSRM demo server is rate-limited; for production point this at a
 * self-hosted instance. When disabled, all methods are safe no-ops.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OsrmClient {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    @Value("${telemetry.osrm.enabled:false}")
    private boolean enabled;

    @Value("${telemetry.osrm.base-url:https://router.project-osrm.org}")
    private String baseUrl;

    @Value("${telemetry.osrm.profile:driving}")
    private String profile;

    /**
     * Snap a sequence of readings to road segments.
     * Returns a GeoJSON LineString string ({@code {"type":"LineString","coordinates":[[lon,lat],...]}}),
     * or null when disabled or on failure.
     */
    public String snapToRoad(List<VehicleReading> readings) {
        if (!enabled || readings == null || readings.size() < 2) return null;

        // OSRM caps /match at 100 coordinates per request — downsample if needed.
        List<VehicleReading> sampled = downsample(readings, 100);

        String coords = sampled.stream()
                .filter(r -> r.getLat() != null && r.getLon() != null)
                .map(r -> r.getLon() + "," + r.getLat())
                .collect(Collectors.joining(";"));
        if (coords.isBlank()) return null;

        String url = baseUrl + "/match/v1/" + profile + "/" + coords
                + "?geometries=geojson&overview=full&tidy=true";

        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(8))
                    .GET().build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) {
                log.warn("OSRM returned status {} for snap request", resp.statusCode());
                return null;
            }
            JsonNode root = MAPPER.readTree(resp.body());
            JsonNode matchings = root.get("matchings");
            if (matchings == null || matchings.isEmpty()) return null;
            JsonNode geometry = matchings.get(0).get("geometry");
            return geometry == null ? null : geometry.toString();
        } catch (Exception e) {
            log.warn("OSRM snap-to-road failed: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Parse stored snapped-geometry JSON back into a list of [lon, lat] pairs.
     * Returns null on missing/invalid input.
     */
    public List<double[]> parseGeometry(String json) {
        if (json == null || json.isBlank()) return null;
        try {
            JsonNode node = MAPPER.readTree(json);
            JsonNode coords = node.has("coordinates") ? node.get("coordinates") : node;
            List<List<Double>> raw = MAPPER.convertValue(
                    coords, new TypeReference<List<List<Double>>>() {});
            return raw.stream()
                    .filter(p -> p.size() >= 2)
                    .map(p -> new double[]{ p.get(0), p.get(1) })
                    .toList();
        } catch (Exception e) {
            log.warn("Failed to parse snapped geometry: {}", e.getMessage());
            return null;
        }
    }

    private List<VehicleReading> downsample(List<VehicleReading> in, int max) {
        if (in.size() <= max) return in;
        int step = (int) Math.ceil(in.size() / (double) max);
        List<VehicleReading> out = new ArrayList<>(max);
        for (int i = 0; i < in.size(); i += step) out.add(in.get(i));
        // Always include the very last point so the snapped route reaches the destination
        if (out.get(out.size() - 1) != in.get(in.size() - 1)) {
            out.add(in.get(in.size() - 1));
        }
        return out;
    }
}
