import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Flame, Zap, Pause, Globe2 } from 'lucide-react';
import Topbar from '../components/layout/Topbar';
import { Card, CardHeader, CardBody } from '../components/common/Card';
import LoadingBlock from '../components/common/LoadingBlock';
import EmptyState from '../components/common/EmptyState';
import HeatmapLayer from '../components/geo/HeatmapLayer';
import { fetchHeatmap } from '../api/geoAnalytics';

const KINDS = [
  { value: 'speeding', label: 'Speeding hotspots', Icon: Zap, hint: 'Readings above the threshold' },
  { value: 'idle',     label: 'Idle zones',        Icon: Pause, hint: 'Readings with speed < 1 km/h' },
  { value: 'any',      label: 'All activity',      Icon: Globe2, hint: 'Every reading, all speeds' },
];

const RANGES = [
  { label: 'Last 24h',  ms: 24 * 60 * 60 * 1000 },
  { label: 'Last 7d',   ms: 7 * 24 * 60 * 60 * 1000 },
  { label: 'Last 30d',  ms: 30 * 24 * 60 * 60 * 1000 },
];

export default function HeatmapPage() {
  const [kind, setKind] = useState('speeding');
  const [rangeMs, setRangeMs] = useState(RANGES[1].ms);
  const [threshold, setThreshold] = useState(80);

  const { from, to } = useMemo(() => {
    const t = Date.now();
    return { from: t - rangeMs, to: t };
  }, [rangeMs]);

  const heatmapQuery = useQuery({
    queryKey: ['heatmap', kind, from, to, threshold],
    queryFn: () => fetchHeatmap({ kind, from, to, threshold, precision: 3 }),
    keepPreviousData: true,
  });

  const cells = heatmapQuery.data?.cells ?? [];

  const center = useMemo(() => {
    if (!cells.length) return [12.97, 77.59];
    const lat = cells.reduce((s, c) => s + c.lat, 0) / cells.length;
    const lon = cells.reduce((s, c) => s + c.lon, 0) / cells.length;
    return [lat, lon];
  }, [cells]);

  const totalReadings = cells.reduce((s, c) => s + c.weight, 0);
  const peak = cells.reduce((m, c) => (c.weight > m ? c.weight : m), 0);

  return (
    <>
      <Topbar
        title="Heatmap"
        subtitle="Where your fleet spends time, idles, or exceeds the speed threshold"
      />

      <div className="p-6 space-y-6">
        <Card>
          <CardBody>
            <div className="flex flex-wrap items-end gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                  Metric
                </label>
                <div className="inline-flex rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5">
                  {KINDS.map((k) => {
                    const Icon = k.Icon;
                    const active = k.value === kind;
                    return (
                      <button
                        key={k.value}
                        onClick={() => setKind(k.value)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-sm font-medium transition ${
                          active
                            ? 'bg-brand-600 text-white'
                            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Icon className="h-3.5 w-3.5" />
                        {k.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                  Time range
                </label>
                <div className="inline-flex rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5">
                  {RANGES.map((r) => {
                    const active = r.ms === rangeMs;
                    return (
                      <button
                        key={r.label}
                        onClick={() => setRangeMs(r.ms)}
                        className={`px-3 py-1.5 rounded text-sm font-medium transition ${
                          active
                            ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        {r.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {kind === 'speeding' && (
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                    Speeding threshold ({threshold} km/h)
                  </label>
                  <input
                    type="range"
                    min={40}
                    max={140}
                    step={5}
                    value={threshold}
                    onChange={(e) => setThreshold(Number(e.target.value))}
                    className="w-48 accent-brand-600"
                  />
                </div>
              )}

              <div className="ml-auto text-xs text-slate-500 dark:text-slate-400 text-right">
                <div><strong className="text-slate-900 dark:text-slate-100 tabular-nums">{cells.length}</strong> cells</div>
                <div><strong className="text-slate-900 dark:text-slate-100 tabular-nums">{totalReadings}</strong> readings · peak {peak}</div>
              </div>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title={KINDS.find((k) => k.value === kind)?.label} subtitle={KINDS.find((k) => k.value === kind)?.hint} />
          <CardBody>
            {heatmapQuery.isPending ? (
              <LoadingBlock />
            ) : cells.length === 0 ? (
              <EmptyState
                icon={Flame}
                title="No matching readings"
                message="Widen the time range or drop the speed threshold."
              />
            ) : (
              <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                <MapContainer
                  center={center}
                  zoom={11}
                  style={{ height: 560, width: '100%' }}
                  scrollWheelZoom
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <HeatmapLayer cells={cells} kind={kind} />
                </MapContainer>
              </div>
            )}
          </CardBody>
        </Card>
      </div>
    </>
  );
}
