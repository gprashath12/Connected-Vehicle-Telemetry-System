import { apiClient } from './client';

// GET /api/geo-analytics/heatmap?kind=...&from=...&to=...&threshold=...&precision=...
export async function fetchHeatmap({ kind = 'any', from, to, threshold = 80, precision = 3 }) {
  const { data } = await apiClient.get('/geo-analytics/heatmap', {
    params: { kind, from, to, threshold, precision },
  });
  return data;
}
