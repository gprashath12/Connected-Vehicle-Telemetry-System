package com.telemetry.exception;

public class GeofenceAccessDeniedException extends RuntimeException {
    public GeofenceAccessDeniedException() { super("You do not have access to this geofence"); }
}
