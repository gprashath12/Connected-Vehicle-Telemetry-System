package com.telemetry.dto.geo;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;

@Data
public class CreateGeofenceRequest {

    @NotBlank
    @Size(max = 120)
    private String name;

    @Size(max = 500)
    private String description;

    /** DEPOT | CUSTOMER_SITE | RESTRICTED | CUSTOM */
    private String category = "CUSTOM";

    @Size(min = 4, max = 9)
    private String color = "#2563eb";

    /** Vertices [[lat, lon], ...] — at least 3 points needed for a polygon. */
    @NotEmpty
    @Size(min = 3, message = "Polygon needs at least 3 vertices")
    private List<double[]> polygon;

    private boolean enabled = true;
    private boolean alertOnEntry = true;
    private boolean alertOnExit = true;
}
