package com.telemetry.service;

import com.telemetry.dto.geo.CreateGeofenceRequest;
import com.telemetry.dto.geo.GeofenceDto;
import com.telemetry.dto.geo.GeofenceEventDto;
import com.telemetry.entity.*;
import com.telemetry.exception.GeofenceAccessDeniedException;
import com.telemetry.exception.GeofenceNotFoundException;
import com.telemetry.repository.GeofenceEventRepository;
import com.telemetry.repository.GeofenceRepository;
import com.telemetry.repository.UserRepository;
import com.telemetry.repository.VehicleRepository;
import com.telemetry.util.GeoMath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class GeofenceService {

    private final GeofenceRepository geofenceRepo;
    private final GeofenceEventRepository eventRepo;
    private final VehicleRepository vehicleRepo;
    private final UserRepository userRepo;

    /**
     * Per-vehicle membership set: which geofence ids the vehicle was inside last tick.
     * Used to detect transitions (entry/exit) without keeping that state in the DB hot path.
     */
    private final Map<Long, Set<Long>> membership = new ConcurrentHashMap<>();

    /* ───────────────── CRUD ───────────────── */

    public List<GeofenceDto> list(User current) {
        List<Geofence> fences = (current.getRole() == Role.ADMIN)
                ? geofenceRepo.findAll()
                : geofenceRepo.findByOwnerOrdered(current.getUserId());
        return fences.stream().map(GeofenceDto::from).toList();
    }

    public GeofenceDto get(Long id, User current) {
        return GeofenceDto.from(loadAuthorized(id, current));
    }

    @Transactional
    public GeofenceDto create(CreateGeofenceRequest req, User current) {
        Geofence g = new Geofence();
        g.setName(req.getName().trim());
        g.setDescription(req.getDescription());
        g.setCategory(parseCategory(req.getCategory()));
        g.setColor(req.getColor() != null ? req.getColor() : "#2563eb");
        g.setPolygonJson(GeoMath.toPolygonJson(req.getPolygon()));
        GeoMath.recomputeBounds(g);
        g.setEnabled(req.isEnabled());
        g.setAlertOnEntry(req.isAlertOnEntry());
        g.setAlertOnExit(req.isAlertOnExit());
        g.setOwner(current);
        g.setCreatedAt(Instant.now());
        return GeofenceDto.from(geofenceRepo.save(g));
    }

    @Transactional
    public GeofenceDto update(Long id, CreateGeofenceRequest req, User current) {
        Geofence g = loadAuthorized(id, current);
        g.setName(req.getName().trim());
        g.setDescription(req.getDescription());
        g.setCategory(parseCategory(req.getCategory()));
        g.setColor(req.getColor() != null ? req.getColor() : g.getColor());
        g.setPolygonJson(GeoMath.toPolygonJson(req.getPolygon()));
        GeoMath.recomputeBounds(g);
        g.setEnabled(req.isEnabled());
        g.setAlertOnEntry(req.isAlertOnEntry());
        g.setAlertOnExit(req.isAlertOnExit());
        return GeofenceDto.from(geofenceRepo.save(g));
    }

    @Transactional
    public void delete(Long id, User current) {
        Geofence g = loadAuthorized(id, current);
        eventRepo.deleteByGeofenceId(g.getGeofenceId());
        geofenceRepo.delete(g);
        // Invalidate cached membership entries that referenced this fence
        for (Set<Long> s : membership.values()) s.remove(id);
    }

    /* ───────────────── Events ───────────────── */

    public List<GeofenceEventDto> recentEventsForCurrentUser(User current) {
        List<Long> vehicleIds = vehicleIdsFor(current);
        if (vehicleIds.isEmpty()) return List.of();
        List<GeofenceEvent> events = eventRepo.findRecentByVehicles(vehicleIds);
        return enrich(events);
    }

    public long unacknowledgedCount(User current) {
        List<Long> vehicleIds = vehicleIdsFor(current);
        return vehicleIds.isEmpty() ? 0 : eventRepo.countUnacknowledged(vehicleIds);
    }

    @Transactional
    public void acknowledge(Long eventId, User current) {
        GeofenceEvent e = eventRepo.findById(eventId)
                .orElseThrow(() -> new IllegalArgumentException("Event not found"));
        if (current.getRole() != Role.ADMIN) {
            Vehicle v = vehicleRepo.findById(e.getVehicleid()).orElse(null);
            if (v == null || v.getOwnerId() == null || !v.getOwnerId().equals(current.getUserId())) {
                throw new GeofenceAccessDeniedException();
            }
        }
        e.setAcknowledged(true);
        eventRepo.save(e);
    }

    /* ───────────────── Runtime evaluation ─────────────────
       Called by VehicleSimulator on every tick, after a new reading has been
       computed but before it's persisted, so we know the vehicle's current
       lat/lon. */

    /**
     * Check the given reading against all enabled geofences belonging to the
     * vehicle's owner. Persists ENTRY/EXIT events for any transitions.
     */
    @Transactional
    public void evaluate(Vehicle v, double lat, double lon, double speed, Instant ts) {
        Long ownerId = v.getOwnerId();
        if (ownerId == null) return;

        List<Geofence> fences = geofenceRepo.findEnabledByOwner(ownerId);
        if (fences.isEmpty()) {
            membership.remove(v.getVehicleid());
            return;
        }

        Set<Long> previous = membership.computeIfAbsent(v.getVehicleid(),
                id -> ConcurrentHashMap.newKeySet());
        Set<Long> current = new HashSet<>();

        List<GeofenceEvent> toWrite = new ArrayList<>();

        for (Geofence g : fences) {
            if (!GeoMath.inBoundingBox(lat, lon, g)) continue; // fast reject
            List<double[]> verts = GeoMath.parsePolygon(g.getPolygonJson());
            if (GeoMath.pointInPolygon(lat, lon, verts)) {
                current.add(g.getGeofenceId());
            }
        }

        // ENTRY = in current, not in previous
        for (Long id : current) {
            if (!previous.contains(id)) {
                Geofence g = fences.stream().filter(f -> f.getGeofenceId().equals(id)).findFirst().orElse(null);
                if (g != null && g.isAlertOnEntry()) {
                    toWrite.add(buildEvent(v.getVehicleid(), id, GeofenceEvent.Type.ENTRY, lat, lon, speed, ts));
                }
            }
        }
        // EXIT = in previous, not in current
        for (Long id : previous) {
            if (!current.contains(id)) {
                Geofence g = fences.stream().filter(f -> f.getGeofenceId().equals(id)).findFirst().orElse(null);
                if (g != null && g.isAlertOnExit()) {
                    toWrite.add(buildEvent(v.getVehicleid(), id, GeofenceEvent.Type.EXIT, lat, lon, speed, ts));
                }
            }
        }

        if (!toWrite.isEmpty()) {
            eventRepo.saveAll(toWrite);
            if (log.isInfoEnabled()) {
                log.info("Geofence transitions for vehicle {}: {} event(s)", v.getVehicleid(), toWrite.size());
            }
        }

        // Replace previous with current
        previous.clear();
        previous.addAll(current);
    }

    /* ───────────────── Helpers ───────────────── */

    private Geofence loadAuthorized(Long id, User current) {
        Geofence g = geofenceRepo.findById(id).orElseThrow(GeofenceNotFoundException::new);
        if (current.getRole() != Role.ADMIN) {
            Long ownerId = g.getOwnerId();
            if (ownerId == null || !ownerId.equals(current.getUserId())) {
                throw new GeofenceAccessDeniedException();
            }
        }
        return g;
    }

    private Geofence.Category parseCategory(String s) {
        if (s == null) return Geofence.Category.CUSTOM;
        try { return Geofence.Category.valueOf(s.toUpperCase()); }
        catch (Exception e) { return Geofence.Category.CUSTOM; }
    }

    private List<Long> vehicleIdsFor(User current) {
        if (current.getRole() == Role.ADMIN) {
            return vehicleRepo.findAll().stream().map(Vehicle::getVehicleid).toList();
        }
        return vehicleRepo.findByOwnerOrdered(current.getUserId()).stream()
                .map(Vehicle::getVehicleid).toList();
    }

    private GeofenceEvent buildEvent(Long vid, Long gid, GeofenceEvent.Type type,
                                     double lat, double lon, double speed, Instant ts) {
        GeofenceEvent e = new GeofenceEvent();
        e.setVehicleid(vid);
        e.setGeofenceId(gid);
        e.setEventType(type);
        e.setLat(lat);
        e.setLon(lon);
        e.setSpeed(speed);
        e.setTs(ts);
        e.setAcknowledged(false);
        return e;
    }

    private List<GeofenceEventDto> enrich(List<GeofenceEvent> events) {
        if (events.isEmpty()) return List.of();
        Map<Long, Vehicle> vMap = vehicleRepo.findAllById(
                events.stream().map(GeofenceEvent::getVehicleid).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Vehicle::getVehicleid, x -> x));
        Map<Long, Geofence> gMap = geofenceRepo.findAllById(
                events.stream().map(GeofenceEvent::getGeofenceId).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Geofence::getGeofenceId, x -> x));

        return events.stream().map(e -> {
            GeofenceEventDto dto = GeofenceEventDto.from(e);
            Vehicle v = vMap.get(e.getVehicleid());
            if (v != null) {
                dto.setVehicleName(v.getName());
                dto.setVehicleCode(v.getVehicle_code());
            }
            Geofence g = gMap.get(e.getGeofenceId());
            if (g != null) {
                dto.setGeofenceName(g.getName());
                dto.setCategory(g.getCategory().name());
            }
            return dto;
        }).toList();
    }
}
