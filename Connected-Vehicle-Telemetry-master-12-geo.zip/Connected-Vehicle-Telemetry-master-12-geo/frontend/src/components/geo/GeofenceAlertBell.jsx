import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Bell } from 'lucide-react';
import { fetchUnacknowledgedCount } from '../../api/geofences';

/**
 * Lightweight badge that polls the unacknowledged geofence event count.
 * Links to /geofences where the user can acknowledge them.
 */
export default function GeofenceAlertBell() {
  const { data: count } = useQuery({
    queryKey: ['geofence-unack-count'],
    queryFn: fetchUnacknowledgedCount,
    refetchInterval: 30_000,
  });

  const has = typeof count === 'number' && count > 0;

  return (
    <Link
      to="/geofences"
      className="relative inline-flex items-center justify-center h-8 w-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition"
      aria-label="Geofence alerts"
      title={has ? `${count} unacknowledged geofence event${count === 1 ? '' : 's'}` : 'No new geofence events'}
    >
      <Bell className={`h-4 w-4 ${has ? 'text-rose-500' : 'text-slate-400'}`} />
      {has && (
        <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
          {count > 99 ? '99+' : count}
        </span>
      )}
    </Link>
  );
}
