package com.telemetry.dto.geo;

import com.telemetry.entity.Trip;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TripDto {
    private Long tripId;
    private Long vehicleId;
    private Instant startTs;
    private Instant endTs;
    private Double startLat;
    private Double startLon;
    private Double endLat;
    private Double endLon;
    private Double distanceKm;
    private Double maxSpeed;
    private Double avgSpeed;
    private Integer idleMinutes;
    private Integer pointCount;
    private Long durationMinutes;

    public static TripDto from(Trip t) {
        TripDto d = new TripDto();
        d.tripId        = t.getTripId();
        d.vehicleId     = t.getVehicleid();
        d.startTs       = t.getStartTs();
        d.endTs         = t.getEndTs();
        d.startLat      = t.getStartLat();
        d.startLon      = t.getStartLon();
        d.endLat        = t.getEndLat();
        d.endLon        = t.getEndLon();
        d.distanceKm    = t.getDistanceKm();
        d.maxSpeed      = t.getMaxSpeed();
        d.avgSpeed      = t.getAvgSpeed();
        d.idleMinutes   = t.getIdleMinutes();
        d.pointCount    = t.getPointCount();
        d.durationMinutes = (t.getEndTs().toEpochMilli() - t.getStartTs().toEpochMilli()) / 60_000L;
        return d;
    }
}
