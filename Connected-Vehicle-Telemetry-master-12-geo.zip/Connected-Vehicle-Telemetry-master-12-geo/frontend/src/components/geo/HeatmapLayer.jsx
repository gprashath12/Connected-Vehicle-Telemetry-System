import { useMemo } from 'react';
import { Polyline, Tooltip } from 'react-leaflet';

/**
 * Line-based heatmap. Grid cells (from the backend at precision=3) are connected
 * to their axis-aligned neighbors and rendered as colored Polylines whose stroke
 * width and opacity scale with intensity. Isolated cells are shown as a short
 * tick mark so they are never invisible.
 *
 * Color gradients per metric:
 *   speeding  → yellow → red
 *   idle      → sky-blue → navy
 *   any       → teal → purple
 */
export default function HeatmapLayer({ cells = [], kind = 'speeding' }) {
  const max = useMemo(
    () => cells.reduce((m, c) => (c.weight > m ? c.weight : m), 1),
    [cells],
  );

  const { segments, isolated } = useMemo(() => buildNetwork(cells), [cells]);

  return (
    <>
      {segments.map(({ from, to }, i) => {
        const t = ((from.weight + to.weight) / 2) / max;
        const color = colorFor(kind, t);
        return (
          <Polyline
            key={i}
            positions={[
              [from.lat, from.lon],
              [to.lat, to.lon],
            ]}
            pathOptions={{
              color,
              weight: 2 + Math.round(t * 7),
              opacity: 0.5 + t * 0.45,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          >
            <Tooltip direction="top" sticky>
              <span className="text-xs">
                avg {Math.round((from.weight + to.weight) / 2)} reading
                {Math.round((from.weight + to.weight) / 2) === 1 ? '' : 's'}
              </span>
            </Tooltip>
          </Polyline>
        );
      })}

      {/* Isolated cells with no neighbors – render as a tiny horizontal tick */}
      {isolated.map((c, i) => {
        const t = c.weight / max;
        const color = colorFor(kind, t);
        const d = 0.0004; // ~44 m half-length at equator
        return (
          <Polyline
            key={`iso-${i}`}
            positions={[
              [c.lat, c.lon - d],
              [c.lat, c.lon + d],
            ]}
            pathOptions={{
              color,
              weight: 2 + Math.round(t * 5),
              opacity: 0.5 + t * 0.45,
              lineCap: 'round',
            }}
          >
            <Tooltip direction="top" sticky>
              <span className="text-xs">
                {c.weight} reading{c.weight === 1 ? '' : 's'}
              </span>
            </Tooltip>
          </Polyline>
        );
      })}
    </>
  );
}

/**
 * Builds a set of grid-adjacent connections between cells.
 * Cells are quantised to 0.001° buckets (backend precision=3).
 * Each cell is connected to its east and north neighbor when present.
 * Returns { segments, isolated }.
 */
function buildNetwork(cells) {
  if (!cells.length) return { segments: [], isolated: [] };

  // Spatial hash: "rLat,rLon" → cell
  const grid = new Map();
  cells.forEach((c) => {
    const key = `${Math.round(c.lat * 1000)},${Math.round(c.lon * 1000)}`;
    grid.set(key, c);
  });

  const segments = [];
  const connectedKeys = new Set();

  cells.forEach((c) => {
    const rLat = Math.round(c.lat * 1000);
    const rLon = Math.round(c.lon * 1000);
    const thisKey = `${rLat},${rLon}`;

    // East + North + North-east neighbors (avoids duplicate lines)
    const checks = [
      [rLat, rLon + 1],
      [rLat + 1, rLon],
      [rLat + 1, rLon + 1],
    ];

    checks.forEach(([nLat, nLon]) => {
      const neighbor = grid.get(`${nLat},${nLon}`);
      if (neighbor) {
        segments.push({ from: c, to: neighbor });
        connectedKeys.add(thisKey);
        connectedKeys.add(`${nLat},${nLon}`);
      }
    });
  });

  const isolated = cells.filter((c) => {
    const key = `${Math.round(c.lat * 1000)},${Math.round(c.lon * 1000)}`;
    return !connectedKeys.has(key);
  });

  return { segments, isolated };
}

function colorFor(kind, t) {
  const stops = {
    speeding: [
      [255, 213, 0],
      [220, 38, 38],
    ],
    idle: [
      [56, 189, 248],
      [30, 58, 138],
    ],
    any: [
      [16, 185, 129],
      [124, 58, 237],
    ],
  }[kind] ?? [
    [56, 189, 248],
    [30, 58, 138],
  ];

  const [a, b] = stops;
  const r = Math.round(a[0] + (b[0] - a[0]) * t);
  const g = Math.round(a[1] + (b[1] - a[1]) * t);
  const bl = Math.round(a[2] + (b[2] - a[2]) * t);
  return `rgb(${r},${g},${bl})`;
}
