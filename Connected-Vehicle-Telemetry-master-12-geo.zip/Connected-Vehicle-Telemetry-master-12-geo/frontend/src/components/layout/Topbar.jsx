export default function Topbar({ title, subtitle, right }) {
  return (
    <header className="h-14 shrink-0 border-b border-slate-200 dark:border-slate-800 px-6 flex items-center justify-between bg-white dark:bg-slate-900">
      <div className="min-w-0">
        <h1 className="text-base font-semibold text-slate-900 dark:text-slate-100 leading-tight truncate">
          {title}
        </h1>
        {subtitle && (
          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{subtitle}</p>
        )}
      </div>
      {right && <div className="flex items-center gap-2 ml-4 shrink-0">{right}</div>}
    </header>
  );
}
