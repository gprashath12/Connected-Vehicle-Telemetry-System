import { useEffect, useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Route,
  RefreshCw,
  Sparkles,
  Clock,
  Activity,
  Gauge,
  MapPin,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
} from 'lucide-react';
import Topbar from '../components/layout/Topbar';
import { Card, CardHeader, CardBody } from '../components/common/Card';
import LoadingBlock from '../components/common/LoadingBlock';
import EmptyState from '../components/common/EmptyState';
import VehicleSelector from '../components/common/VehicleSelector';
import TripPlayer from '../components/geo/TripPlayer';
import { fetchVehicles } from '../api/vehicles';
import { fetchTripsForVehicle, fetchTripDetail, snapTrip, rebuildTripsForVehicle } from '../api/trips';
import { formatDuration } from '../lib/timeAgo';

/** Returns "YYYY-MM-DD" in local time for a Date object. */
function toDateValue(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/** Human-readable label for a date string "YYYY-MM-DD". */
function dateLabel(str) {
  const d = new Date(str + 'T00:00:00');
  const today = toDateValue(new Date());
  const yest = toDateValue(new Date(Date.now() - 86400000));
  if (str === today) return 'Today';
  if (str === yest) return 'Yesterday';
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: d.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined,
  });
}

export default function TripsPage() {
  const queryClient = useQueryClient();
  const [vehicleId, setVehicleId] = useState(null);
  const [tripId, setTripId] = useState(null);
  const [selectedDate, setSelectedDate] = useState(toDateValue(new Date())); // YYYY-MM-DD

  const vehiclesQuery = useQuery({
    queryKey: ['vehicles'],
    queryFn: fetchVehicles,
  });

  useEffect(() => {
    if (vehicleId == null && vehiclesQuery.data?.length) {
      setVehicleId(vehiclesQuery.data[0].vehicleid);
    }
  }, [vehiclesQuery.data, vehicleId]);

  const tripsQuery = useQuery({
    queryKey: ['trips', vehicleId],
    queryFn: () => fetchTripsForVehicle(vehicleId),
    enabled: vehicleId != null,
  });

  // When vehicle or date changes, auto-select the first trip of that day.
  const tripsOnDate = useMemo(() => {
    const all = tripsQuery.data ?? [];
    return all.filter((t) => toDateValue(new Date(t.startTs)) === selectedDate);
  }, [tripsQuery.data, selectedDate]);

  useEffect(() => {
    if (tripsOnDate.length) setTripId(tripsOnDate[0].tripId);
    else setTripId(null);
  }, [tripsOnDate]);

  // All distinct dates that have trips, sorted desc
  const tripDates = useMemo(() => {
    const all = tripsQuery.data ?? [];
    const set = new Set(all.map((t) => toDateValue(new Date(t.startTs))));
    return Array.from(set).sort((a, b) => (a > b ? -1 : 1));
  }, [tripsQuery.data]);

  const currentDateIdx = tripDates.indexOf(selectedDate);
  const hasPrev = currentDateIdx < tripDates.length - 1; // older
  const hasNext = currentDateIdx > 0;                     // newer

  const goToPrev = () => {
    if (hasPrev) setSelectedDate(tripDates[currentDateIdx + 1]);
  };
  const goToNext = () => {
    if (hasNext) setSelectedDate(tripDates[currentDateIdx - 1]);
  };

  // If the currently selected date has no trips (e.g. just switched vehicle), snap to first available date
  useEffect(() => {
    if (tripDates.length && !tripDates.includes(selectedDate)) {
      setSelectedDate(tripDates[0]);
    }
  }, [tripDates]); // eslint-disable-line react-hooks/exhaustive-deps

  const detailQuery = useQuery({
    queryKey: ['trip-detail', tripId],
    queryFn: () => fetchTripDetail(tripId),
    enabled: tripId != null,
  });

  const snapMut = useMutation({
    mutationFn: snapTrip,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['trip-detail', tripId] }),
  });

  const rebuildMut = useMutation({
    mutationFn: rebuildTripsForVehicle,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['trips', vehicleId] }),
  });

  return (
    <>
      <Topbar
        title="Trips"
        subtitle="Browse historic trips and replay them on the map"
        right={
          <div className="flex items-center gap-2">
            <VehicleSelector
              vehicles={vehiclesQuery.data ?? []}
              value={vehicleId}
              onChange={(id) => {
                setVehicleId(id);
                setSelectedDate(toDateValue(new Date())); // reset to today on vehicle switch
              }}
            />
            <button
              onClick={() => vehicleId && rebuildMut.mutate(vehicleId)}
              disabled={!vehicleId || rebuildMut.isPending}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-slate-300 dark:border-slate-700 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50"
              title="Re-segment readings into trips"
            >
              <RefreshCw className={`h-4 w-4 ${rebuildMut.isPending ? 'animate-spin' : ''}`} />
              Rebuild
            </button>
          </div>
        }
      />

      <div className="p-6 grid lg:grid-cols-3 gap-6">
        {/* Left panel — date navigator + trip list */}
        <Card className="lg:col-span-1 flex flex-col">
          <CardHeader
            title="Trip history"
            subtitle={
              tripsQuery.data?.length
                ? `${tripsQuery.data.length} trip${tripsQuery.data.length === 1 ? '' : 's'} total`
                : null
            }
          />

          {/* Date navigator */}
          <div className="flex items-center gap-1 px-4 py-2.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <button
              onClick={goToPrev}
              disabled={!hasPrev}
              className="p-1.5 rounded-md text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="Previous day with trips"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>

            <div className="flex-1 flex items-center justify-center gap-2 relative">
              <CalendarDays className="h-3.5 w-3.5 text-brand-500 shrink-0" />
              <label className="relative cursor-pointer">
                <span className="text-sm font-semibold text-slate-800 dark:text-slate-100">
                  {dateLabel(selectedDate)}
                </span>
                <input
                  type="date"
                  value={selectedDate}
                  max={toDateValue(new Date())}
                  onChange={(e) => e.target.value && setSelectedDate(e.target.value)}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full"
                  title="Pick a date"
                />
              </label>
              <span className="text-xs text-slate-400 dark:text-slate-500 tabular-nums">
                ({tripsOnDate.length})
              </span>
            </div>

            <button
              onClick={goToNext}
              disabled={!hasNext}
              className="p-1.5 rounded-md text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="Next day with trips"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>

          {/* Available dates quick-jump pills */}
          {tripDates.length > 1 && (
            <div className="flex gap-1.5 px-4 py-2 overflow-x-auto border-b border-slate-100 dark:border-slate-800 no-scrollbar">
              {tripDates.slice(0, 7).map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDate(d)}
                  className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                    d === selectedDate
                      ? 'bg-brand-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-brand-50 dark:hover:bg-brand-500/20 hover:text-brand-700 dark:hover:text-brand-300'
                  }`}
                >
                  {dateLabel(d)}
                </button>
              ))}
              {tripDates.length > 7 && (
                <span className="shrink-0 px-2 py-1 text-xs text-slate-400 self-center">
                  +{tripDates.length - 7} more
                </span>
              )}
            </div>
          )}

          {/* Trip list for selected date */}
          <CardBody className="p-0 flex-1 max-h-[55vh] overflow-auto">
            {tripsQuery.isPending ? (
              <div className="p-5">
                <LoadingBlock />
              </div>
            ) : tripsOnDate.length === 0 ? (
              <div className="p-5">
                <EmptyState
                  icon={Route}
                  title={tripsQuery.data?.length ? 'No trips on this date' : 'No trips yet'}
                  message={
                    tripsQuery.data?.length
                      ? 'Use the arrows or date picker to navigate to a date with trips.'
                      : 'Once the simulator produces an OFF gap, trips will appear here.'
                  }
                />
              </div>
            ) : (
              <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                {tripsOnDate.map((t) => {
                  const isActive = t.tripId === tripId;
                  return (
                    <li
                      key={t.tripId}
                      onClick={() => setTripId(t.tripId)}
                      className={`px-5 py-3 cursor-pointer transition border-l-2 ${
                        isActive
                          ? 'bg-brand-50 dark:bg-brand-500/10 border-l-brand-600'
                          : 'border-l-transparent hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="text-sm font-medium text-slate-900 dark:text-slate-100 flex items-center gap-2">
                        <Clock className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                        {new Date(t.startTs).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        <span className="ml-auto text-xs text-slate-400 tabular-nums">
                          #{t.tripId}
                        </span>
                      </div>
                      <div className="mt-1.5 grid grid-cols-3 gap-2 text-xs text-slate-600 dark:text-slate-300">
                        <Stat icon={MapPin} label={`${t.distanceKm?.toFixed(1) ?? 0} km`} />
                        <Stat icon={Activity} label={formatDuration(t.durationMinutes)} />
                        <Stat icon={Gauge} label={`${t.maxSpeed?.toFixed(0) ?? 0} km/h`} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardBody>
        </Card>

        {/* Right panel — trip replay */}
        <Card className="lg:col-span-2">
          <CardHeader
            title={detailQuery.data ? `Trip #${detailQuery.data.trip.tripId}` : 'Trip replay'}
            subtitle={
              detailQuery.data
                ? `${detailQuery.data.trip.distanceKm?.toFixed(1) ?? 0} km · ${formatDuration(detailQuery.data.trip.durationMinutes)} · ${detailQuery.data.points.length} GPS points`
                : 'Pick a trip from the list to replay it'
            }
            action={
              detailQuery.data && (
                <button
                  onClick={() => snapMut.mutate(tripId)}
                  disabled={snapMut.isPending}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs bg-brand-50 text-brand-700 hover:bg-brand-100 dark:bg-brand-500/15 dark:text-brand-300 dark:hover:bg-brand-500/25 disabled:opacity-50"
                >
                  <Sparkles className={`h-3.5 w-3.5 ${snapMut.isPending ? 'animate-pulse' : ''}`} />
                  {detailQuery.data.snappedRoute ? 'Re-snap to road' : 'Snap to road'}
                </button>
              )
            }
          />
          <CardBody>
            {!tripId ? (
              <EmptyState
                icon={Route}
                title="Select a trip"
                message="Trip metadata and a map replay will appear here."
              />
            ) : detailQuery.isPending ? (
              <LoadingBlock />
            ) : detailQuery.data ? (
              <>
                <TripPlayer detail={detailQuery.data} />
                {snapMut.error && (
                  <p className="mt-3 text-xs text-rose-600 dark:text-rose-400">
                    Snap failed: {snapMut.error.message}
                  </p>
                )}
                {!detailQuery.data.snappedRoute && (
                  <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                    Tip: enable{' '}
                    <code className="px-1 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                      telemetry.osrm.enabled=true
                    </code>{' '}
                    in application.properties to map-match GPS points to road geometry.
                  </p>
                )}
              </>
            ) : null}
          </CardBody>
        </Card>
      </div>
    </>
  );
}

function Stat({ icon: Icon, label }) {
  return (
    <span className="inline-flex items-center gap-1">
      <Icon className="h-3 w-3 text-slate-400" />
      <span className="tabular-nums">{label}</span>
    </span>
  );
}
