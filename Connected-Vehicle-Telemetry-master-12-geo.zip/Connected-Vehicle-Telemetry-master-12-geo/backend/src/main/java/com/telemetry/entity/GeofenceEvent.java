package com.telemetry.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * One row per vehicle entering or leaving a geofence. Acts as both an audit log
 * and the data source for the alerts UI.
 */
@Entity
@Table(name = "geofence_event", indexes = {
        @Index(name = "idx_gfe_vehicle_ts", columnList = "vehicleid,ts"),
        @Index(name = "idx_gfe_geofence_ts", columnList = "geofence_id,ts"),
        @Index(name = "idx_gfe_ack", columnList = "acknowledged")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GeofenceEvent {

    public enum Type { ENTRY, EXIT }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private Long eventId;

    @Column(name = "vehicleid", nullable = false)
    private Long vehicleid;

    @Column(name = "geofence_id", nullable = false)
    private Long geofenceId;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_type", nullable = false, length = 8)
    private Type eventType;

    @Column(name = "lat") private Double lat;
    @Column(name = "lon") private Double lon;
    @Column(name = "speed") private Double speed;

    @Column(name = "ts", nullable = false)
    private Instant ts;

    @Column(name = "acknowledged", nullable = false)
    private boolean acknowledged = false;
}
